v6.0 original-reference baseline

Python 3.12; pip install -r requirements.txt
python tools/v6_baseline.py --source YOUR_REFERENCE.png --output generated/v6 --through 2

The three archived generation modules are unchanged. The runner isolates their imports and output. Original reference: 2f22ad27-e747-4500-b975-345352f21ba7.png, 1086x1448, SHA256 bbeb4acc9f17aed429d0264e28d82e4b9d9e79beeb73b0693d1391b404381f93.
The historical assemble_html.py expects missing historical working directories; it is not the reproduction entry. The v7.2 review renderer is separate from this v6 generating engine.
