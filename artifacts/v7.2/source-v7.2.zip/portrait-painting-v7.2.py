# portrait-painting-v7.2.py -- complete offline automatic portrait painter
# Windows PowerShell:
#   py -m pip install numpy scipy opencv-python-headless Pillow
#   py .\portrait-painting-v7.2.py --source .\person.jpg --output .\person-painting-v7.2.html
# All guide coordinates come from the selected image. No per-image tuning is required.
# Classical image structure is used, not a trained pose/anatomy model.
from __future__ import annotations
import gzip

def package_player(template, painting_payload, generator_payload):
    """Fill the two inert payload containers, never executable source text."""
    import re
    for element, marker, payload in (("painting-data", "__PAINTING_DATA__", painting_payload),
                                     ("generator-source", "__GENERATOR_SOURCE__", generator_payload)):
        pattern = re.compile(r'(<script\b[^>]*\sid\s*=\s*([\'"])' + re.escape(element) +
                             r'\2[^>]*>)(.*?)(</script\s*>)', re.I | re.S)
        matches = list(pattern.finditer(template))
        if len(matches) != 1:
            raise ValueError(element + " must have exactly one script container")
        if matches[0].group(3).strip() != marker:
            raise ValueError(element + " must contain its unfilled payload marker")
        try:
            value = json.loads(payload)
        except (ValueError, TypeError) as error:
            raise ValueError(element + " payload must be valid JSON") from error
        if not isinstance(value, dict):
            raise ValueError(element + " payload must be a JSON object")
        # A payload string must not close its inert script container. Legitimate
        # example marker text elsewhere in the source is deliberately untouched.
        encoded = json.dumps(value, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c')
        template = pattern.sub(lambda match: match.group(1) + encoded + match.group(4), template, count=1)
    return template

"""Global painting stages and overlapping, unpartitioned attention windows.

``attention_route`` orders candidate *locations*, not painted stroke endpoints.
It never changes stroke geometry and does not create pixel ownership or closed
regions. A caller may reject any candidate after testing the current canvas.
"""
import math

import numpy as np
from scipy.spatial import cKDTree


STAGES = ('composition', 'value', 'volume', 'detail')
INTENTS = ('silhouette', 'plane', 'turn', 'edge', 'accent')


class TimelineValidationError(ValueError):
    def __init__(self, report):
        self.report = report
        super().__init__('Global painting timeline rejected: ' + '; '.join(
            item['code'] for item in report['errors'][:6]))


def _summary(values):
    values = np.asarray(values, dtype=float)
    if not len(values):
        return dict(count=0, mean=0., p95=0., maximum=0.)
    return dict(count=len(values), mean=float(values.mean()),
                p95=float(np.percentile(values, 95)), maximum=float(values.max()))


def attention_route(points, initial_scores, width, height,
                    window_radius=130, bundle_size=10):
    """Return candidate indices and observable soft-attention diagnostics.

    A bundle uses an overlapping circular window. Within that window, source
    importance and proximity to candidate centers jointly rank locations. After
    a bundle the window moves toward nearby high-priority remaining candidates,
    by at most 0.8 radii. Only an empty neighborhood triggers relocation to the
    nearest remaining candidate; it never searches for a distant score maximum.

    Every input index is returned exactly once, including duplicate coordinates.
    Scores are fixed hints: the painting generator remains responsible for
    evaluating current residuals and deciding whether to make an actual mark.
    Neither actual stroke endpoints nor directions enter this function.
    """
    xy = np.asarray(points, dtype=np.float64)
    if xy.size == 0:
        xy = xy.reshape(0, 2)
    scores = np.asarray(initial_scores, dtype=np.float64)
    if xy.ndim != 2 or xy.shape[1] != 2 or scores.shape != (len(xy),):
        raise ValueError('Expected Nx2 points and N initial_scores')
    if not np.isfinite(xy).all() or not np.isfinite(scores).all():
        raise ValueError('Points and scores must be finite')
    if not math.isfinite(float(width)) or not math.isfinite(float(height)) or width <= 0 or height <= 0:
        raise ValueError('Image dimensions must be positive and finite')
    radius = float(window_radius)
    if not math.isfinite(radius) or radius <= 0:
        raise ValueError('window_radius must be positive and finite')
    if isinstance(bundle_size, bool) or int(bundle_size) != bundle_size or bundle_size < 1:
        raise ValueError('bundle_size must be a positive integer')
    bundle_size = int(bundle_size)
    if len(xy) and ((xy[:, 0] < 0).any() or (xy[:, 0] > width).any() or
                    (xy[:, 1] < 0).any() or (xy[:, 1] > height).any()):
        raise ValueError('Candidate locations must lie in the image')
    count = len(xy)
    if not count:
        return [], dict(count=0, windowRadius=radius, bundleSize=bundle_size,
                        bundleCount=0, bundles=[], bundleIds=[], relocations=[],
                        seedSteps=_summary([]), windowSteps=_summary([]))

    nonnegative = np.maximum(scores, 0.)
    positive = nonnegative[nonnegative > 0]
    scale = float(np.percentile(positive, 90)) if len(positive) else 1.
    priority = np.minimum(nonnegative / max(scale, 1.e-12), 3.)
    available = np.ones(count, dtype=bool)
    live_ids = np.arange(count, dtype=np.int64)
    tree = cKDTree(xy)
    removed_since_build = 0

    def rebuild_if_needed():
        nonlocal tree, live_ids, removed_since_build
        if removed_since_build >= max(256, int(.25 * len(live_ids))):
            live_ids = np.flatnonzero(available)
            tree = cKDTree(xy[live_ids])
            removed_since_build = 0

    def neighbors(center, search_radius):
        local = np.asarray(tree.query_ball_point(center, search_radius), dtype=np.int64)
        if not len(local):
            return local
        candidates = live_ids[local]
        return candidates[available[candidates]]

    def nearest(center):
        # Static-tree tombstones are cheap until the next bounded rebuild.
        k = min(16, len(live_ids))
        while k:
            distances, positions = tree.query(center, k=k)
            positions = np.atleast_1d(positions)
            distances = np.atleast_1d(distances)
            candidates = live_ids[positions]
            active = available[candidates]
            if active.any():
                best_distance = distances[active].min()
                tied = candidates[active & (distances <= best_distance + 1.e-10)]
                return int(tied.min())
            if k == len(live_ids):
                return None
            k = min(k * 2, len(live_ids))
        return None

    center = xy[int(np.argmax(priority))].copy()
    cursor = center.copy()
    ordered, bundle_ids, bundles, relocations, window_steps = [], [], [], [], []
    while len(ordered) < count:
        rebuild_if_needed()
        local = neighbors(center, radius)
        if not len(local):
            target = nearest(center)
            if target is None:
                raise RuntimeError('Attention route lost an available candidate')
            old = center.copy()
            center = xy[target].copy()
            distance = float(np.linalg.norm(center - old))
            relocations.append(dict(beforeIndex=len(ordered), distance=distance,
                                    fromPoint=old.tolist(), toPoint=center.tolist(),
                                    reason='nearest remaining candidate after local window emptied'))
            window_steps.append(distance)
            local = neighbors(center, radius)

        # Rank the whole window once, then refine a bounded pool for a coherent
        # bundle. This avoids a quadratic nearest-neighbor scan over all points.
        local_dist = np.linalg.norm(xy[local] - center, axis=1) / radius
        quality = .7 * priority[local] - .3 * local_dist
        pool_size = min(len(local), max(64, bundle_size * 8))
        if pool_size < len(local):
            cutoff = float(np.partition(quality, -pool_size)[-pool_size])
            pool = local[quality >= cutoff]
            pool_quality = quality[quality >= cutoff]
            # Explicit input-index tie break is stable even on a uniform grid.
            ranking = np.lexsort((pool, -pool_quality))[:pool_size]
            pool = pool[ranking]
        else:
            pool = local[np.lexsort((local, -quality))]
        pool_live = np.ones(len(pool), dtype=bool)
        start = len(ordered)
        for _ in range(min(bundle_size, len(pool))):
            choices = np.flatnonzero(pool_live)
            ids = pool[choices]
            distance = np.linalg.norm(xy[ids] - cursor, axis=1) / radius
            central = np.linalg.norm(xy[ids] - center, axis=1) / radius
            merit = .6 * priority[ids] - .3 * distance - .1 * central
            rank = np.lexsort((ids, -merit))[0]
            selected, slot = int(ids[rank]), int(choices[rank])
            ordered.append(selected); bundle_ids.append(len(bundles))
            available[selected] = False; pool_live[slot] = False
            removed_since_build += 1
            cursor = xy[selected]
        stop = len(ordered)
        bundles.append(dict(id=len(bundles), start=start, end=stop,
                            center=center.tolist(), radius=radius, count=stop-start,
                            meanScore=float(scores[np.asarray(ordered[start:stop])].mean())))
        if stop == count:
            break

        # A nearby target can move attention across and back over earlier
        # windows. No point is permanently assigned to any one window.
        nearby = neighbors(center, radius * 2.)
        if len(nearby):
            distance = np.linalg.norm(xy[nearby] - center, axis=1) / radius
            merit = .55 * priority[nearby] - .45 * distance
            target = int(nearby[np.lexsort((nearby, -merit))[0]])
            delta = xy[target] - center
            length = float(np.linalg.norm(delta))
            step = delta * min(.65, (.8 * radius / length) if length else .65)
            center = center + step
            window_steps.append(float(np.linalg.norm(step)))

    route_xy = xy[np.asarray(ordered)]
    steps = np.linalg.norm(np.diff(route_xy, axis=0), axis=1)
    return ordered, dict(count=count, windowRadius=radius, bundleSize=bundle_size,
                         bundleCount=len(bundles), bundles=bundles,
                         bundleIds=bundle_ids, relocations=relocations,
                         seedSteps=_summary(steps), windowSteps=_summary(window_steps),
                         policy='overlapping soft attention; candidate centers only; geometry unchanged')


def build_stage_plan():
    """Only four global jobs; intent suggestions are soft, never partitions."""
    hints = dict(composition=['silhouette', 'plane'], value=['plane'],
                 volume=['turn', 'plane'], detail=['edge', 'accent'])
    reasons = dict(composition='先建立全画面的构图、轮廓与主要色面。',
                   value='构图建立后，统一全画面的明暗关系。',
                   volume='明暗关系建立后，画体积转折与冷暖。',
                   detail='主要低频色面与体积建立后，最后处理边缘与强调。')
    jobs = [dict(id=stage, stage=stage,
                 dependsOn=[] if not index else [STAGES[index-1]],
                 intentHints=hints[stage], reason=reasons[stage])
            for index, stage in enumerate(STAGES)]
    return dict(jobs=jobs, order=list(STAGES), intents=list(INTENTS),
                policy='global stage barriers; open attention windows may cross objects')


def _finite(value):
    return isinstance(value, (int, float, np.number)) and math.isfinite(float(value))


def _stage_events(events):
    records, errors = {}, []
    for event in events:
        stage = event.get('stage', event.get('phase', event.get('jobId', event.get('id'))))
        kind = str(event.get('type', event.get('event', 'interval'))).replace('-', '_')
        if kind in ('stroke', 'stroke_start', 'stroke_end', 'pen_up'):
            continue
        if stage not in STAGES:
            errors.append(dict(code='unknown_stage', stage=stage)); continue
        if kind in ('stage_start', 'phase_start', 'job_start', 'start'):
            if stage in records:
                errors.append(dict(code='duplicate_stage_start', stage=stage))
            records[stage] = dict(event, stage=stage, start=event.get('time', event.get('start')))
        elif kind in ('stage_end', 'phase_end', 'job_end', 'end'):
            record = records.setdefault(stage, dict(stage=stage))
            record.update(event)
            record['end'] = event.get('time', event.get('end'))
        else:
            if stage in records:
                errors.append(dict(code='duplicate_stage_interval', stage=stage))
            records[stage] = dict(event, stage=stage)
    return records, errors


def validate_timeline(events, strokes=None, require_complete=True, raise_on_error=True):
    """Validate global stage intervals and the intent of every supplied stroke.

    Events are {stage,start,end}, or paired {type:'stage_start'|'stage_end',
    stage,time}. Times use any consistent unit. This verifies scheduling only;
    visual evidence that broad color planes are established is a separate image
    quality measurement, never a fabricated per-object completion percentage.
    """
    records, errors = _stage_events(events)
    plan = build_stage_plan()
    evidence = []
    for job in plan['jobs']:
        stage, record = job['stage'], records.get(job['stage'])
        row = dict(job, start=None, end=None)
        if record is None:
            if require_complete:
                errors.append(dict(code='missing_stage', stage=stage))
            evidence.append(row); continue
        start, end = record.get('start'), record.get('end')
        row.update(start=start, end=end, strokeCount=record.get('strokeCount'))
        valid = _finite(start) and _finite(end) and end >= start
        if not valid:
            errors.append(dict(code='invalid_stage_interval', stage=stage, start=start, end=end))
        for dependency in job['dependsOn']:
            before = records.get(dependency)
            before_end = before.get('end') if before else None
            if before is None or not _finite(before_end):
                errors.append(dict(code='stage_dependency_incomplete', stage=stage, dependency=dependency))
            elif _finite(start) and before_end > start + 1.e-9:
                errors.append(dict(code='stage_started_before_dependency_finished', stage=stage,
                                   dependency=dependency, dependencyEnd=before_end, start=start))
        evidence.append(row)
    intent_counts = {intent: 0 for intent in INTENTS}
    stroke_count = 0
    for index, stroke in enumerate(strokes if strokes is not None else []):
        stroke_count += 1
        intent = stroke.get('intent')
        if intent not in INTENTS:
            errors.append(dict(code='invalid_stroke_intent', index=index, intent=intent))
        else:
            intent_counts[intent] += 1
        stage = stroke.get('stage', stroke.get('phase'))
        if stage is not None and stage not in STAGES:
            errors.append(dict(code='invalid_stroke_stage', index=index, stage=stage))
    report = dict(passed=not errors, errors=errors, jobs=evidence,
                  expectedOrder=list(STAGES),
                  observedOrder=sorted(records, key=lambda key: (
                      records[key].get('start') if _finite(records[key].get('start')) else math.inf,
                      STAGES.index(key))),
                  strokeCount=stroke_count, intentCounts=intent_counts,
                  scope='global stage order and stroke intent; image quality is evaluated separately')
    if errors and raise_on_error:
        raise TimelineValidationError(report)
    return report


validate_stage_timeline = validate_timeline




"""Pixel-derived open painting movements; no reference-composition templates.

The temporary colour/support arrays in this module are *analysis* fields only.
They are discarded after extracting open centre lines and brush radii. Nothing
here clips paint, assigns a pixel to a body part, or produces a paint mask.

This is a classical-vision approximation to large visual masses, not a trained
human-pose or anatomy recognizer. The caller must preserve that distinction.
Dependencies: numpy, scipy, opencv-python.
"""

import math
import cv2
import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import dijkstra
from scipy.spatial import cKDTree


def _thin(mask):
    """Zhang--Suen thinning, implemented locally to avoid extra dependencies."""
    image = np.pad(mask.astype(np.uint8), 1)
    for _ in range(max(mask.shape)):
        changed = False
        for phase in (0, 1):
            p = image[1:-1, 1:-1]
            n = [image[:-2, 1:-1], image[:-2, 2:], image[1:-1, 2:],
                 image[2:, 2:], image[2:, 1:-1], image[2:, :-2],
                 image[1:-1, :-2], image[:-2, :-2]]
            neighbors = sum(n)
            transitions = sum((n[i] == 0) & (n[(i+1) % 8] == 1) for i in range(8))
            remove = ((p == 1) & (neighbors >= 2) & (neighbors <= 6) & (transitions == 1))
            if phase == 0:
                remove &= (n[0]*n[2]*n[4] == 0) & (n[2]*n[4]*n[6] == 0)
            else:
                remove &= (n[0]*n[2]*n[6] == 0) & (n[0]*n[4]*n[6] == 0)
            if remove.any():
                p[remove] = 0
                changed = True
        if not changed:
            break
    return image[1:-1, 1:-1].astype(bool)


def _pca_path(mask, distance):
    yx = np.argwhere(mask)
    if len(yx) < 8:
        return None
    xy = yx[:, ::-1].astype(float)
    weights = np.maximum(.25, distance[mask].astype(float))
    center = np.average(xy, axis=0, weights=weights)
    covariance = ((xy-center)*weights[:, None]).T @ (xy-center)/weights.sum()
    values, vectors = np.linalg.eigh(covariance)
    axis = vectors[:, -1]
    normal = np.array([-axis[1], axis[0]])
    along = (xy-center) @ axis
    lo, hi = np.percentile(along, [4., 96.])
    if hi-lo < 5.:
        return None
    t = np.linspace(lo, hi, max(5, int((hi-lo)/3.)))
    points = center+axis*t[:, None]
    across = np.abs((xy-center) @ normal)
    radius = max(1.5, float(np.percentile(across, 65)))
    # Use broad cross sections rather than the distance at the centre pixel:
    # eyes/highlights inside a face must not make its base axis snake around
    # them or collapse its load to a hairline.
    radii = np.full(len(points), radius)
    half_bin = max(3., (hi-lo)/max(5., len(points)*.4))
    for index, position in enumerate(t):
        local = np.abs(along-position) <= half_bin
        if local.sum() >= 5:
            radii[index] = np.clip(np.percentile(across[local], 70), radius*.45, radius*1.15)
    radii = gaussian_filter1d(radii, 2., mode='nearest')
    return points, radii


def _graph_path(skeleton, distance, allow):
    yx = np.argwhere(skeleton & allow)
    if len(yx) < 5:
        return None
    ids = np.full(skeleton.shape, -1, np.int32)
    ids[yx[:, 0], yx[:, 1]] = np.arange(len(yx))
    rows, cols, lengths = [], [], []
    h, w = skeleton.shape
    for dy, dx in ((0, 1), (1, 0), (1, 1), (1, -1)):
        q = yx+np.array([dy, dx])
        inside = (q[:, 0] >= 0) & (q[:, 0] < h) & (q[:, 1] >= 0) & (q[:, 1] < w)
        start = np.flatnonzero(inside)
        end = ids[q[inside, 0], q[inside, 1]]
        valid = end >= 0
        start, end = start[valid], end[valid]
        rows.extend(start); cols.extend(end)
        lengths.extend(np.full(len(start), math.hypot(dx, dy)))
        rows.extend(end); cols.extend(start)
        lengths.extend(np.full(len(start), math.hypot(dx, dy)))
    if not rows:
        return None
    graph = csr_matrix((lengths, (rows, cols)), shape=(len(yx), len(yx)))
    seed = int(np.argmax(distance[yx[:, 0], yx[:, 1]]))
    first = dijkstra(graph, indices=seed)
    first[~np.isfinite(first)] = -1
    beginning = int(first.argmax())
    distances, previous = dijkstra(graph, indices=beginning, return_predecessors=True)
    distances[~np.isfinite(distances)] = -1
    end = int(distances.argmax())
    if distances[end] < 7.:
        return None
    path = [end]
    while path[-1] != beginning:
        parent = int(previous[path[-1]])
        if parent < 0 or len(path) > len(yx):
            return None
        path.append(parent)
    points = yx[path[::-1], ::-1].astype(float)
    radii = distance[yx[path[::-1], 0], yx[path[::-1], 1]].astype(float)
    return points, radii


def _clean_path(points, radii, shape):
    if len(points) < 3:
        return None
    # A broad loaded brush follows volume, not every turn of a pixel skeleton.
    # Thin ribbon axes retain their bends; thick planes get stronger smoothing.
    step = max(.5, float(np.median(np.linalg.norm(np.diff(points, axis=0), axis=1))))
    sigma = max(2., min(14., float(np.median(radii))*.70)/step)
    points = gaussian_filter1d(points, sigma, axis=0, mode='nearest')
    radii = gaussian_filter1d(radii, 2.8, mode='nearest')
    lengths = np.r_[0., np.cumsum(np.linalg.norm(np.diff(points, axis=0), axis=1))]
    length = float(lengths[-1])
    if length < max(11., min(shape)*.055):
        return None
    # Resampling keeps the output sparse but does not turn it into contours.
    positions = np.linspace(0., length, max(5, int(length/5.)+1))
    points = np.column_stack([np.interp(positions, lengths, points[:, k]) for k in (0, 1)])
    radii = np.interp(positions, lengths, radii)
    radii = np.clip(radii*1.08, 1.6, min(shape)*.24)
    if points[-1, 1] < points[0, 1] or (abs(points[-1, 1]-points[0, 1]) < 3 and points[-1, 0] < points[0, 0]):
        points, radii = points[::-1], radii[::-1]
    return points, radii, length


def _candidate_paths(mask, origin, background, max_paths=3):
    count, labels, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), 8)
    candidates = []
    minimum_area = max(55, int(mask.size*.0013))
    for index in np.argsort(stats[1:, cv2.CC_STAT_AREA])[::-1][:12]+1:
        area = int(stats[index, cv2.CC_STAT_AREA])
        if area < minimum_area:
            continue
        component = labels == index
        distance = cv2.distanceTransform(np.pad(component.astype(np.uint8), 1), cv2.DIST_L2, 5)[1:-1, 1:-1]
        coordinates = np.argwhere(component)[:, ::-1].astype(float)
        covariance = np.cov(coordinates, rowvar=False)
        eigenvalues = np.maximum(np.linalg.eigvalsh(covariance), .01)
        # Compact colour masses (head, cheek, chest, broad cloth or backdrop)
        # are laid in along their principal volume axis. A medial skeleton of
        # such a mass otherwise circles its internal dark/light holes.
        compact = bool(eigenvalues[-1]/eigenvalues[0] < 4.5)
        skeleton = _thin(component)
        allow = np.ones(component.shape, bool)
        for iteration in range(max_paths):
            result = _pca_path(component, distance) if compact else _graph_path(skeleton, distance, allow)
            if result is None:
                if iteration == 0:
                    result = _pca_path(component, distance)
                if result is None:
                    break
            raw_points, raw_radii = result
            raw_length = float(np.linalg.norm(np.diff(raw_points, axis=0), axis=1).sum())
            chord = float(np.linalg.norm(raw_points[-1]-raw_points[0]))
            slenderness = raw_length/max(1., 2.*float(np.median(raw_radii)))
            # A wide mass must not make a U-turn simply because two nearby
            # pigment islands touch. True long, narrow ribbons keep their arc.
            if not compact and raw_length/max(1., chord) > 1.65 and slenderness < 15.:
                principal = _pca_path(component, distance)
                if principal is not None:
                    result = principal
                    compact = True
            cleaned = _clean_path(*result, mask.shape)
            if cleaned is None:
                break
            points, radii, length = cleaned
            mean_radius = float(np.mean(radii))
            # Isolated hairs, jewelry and droplets are detail, not main masses.
            if mean_radius < max(2., min(mask.shape)*.008) or length < mean_radius*1.6:
                break
            candidates.append(dict(points=points, radii=radii, length=length,
                                   area=area, background=bool(background), origin=origin,
                                   score=float(length*mean_radius**.85)))
            if compact:
                break
            yy, xx = np.indices(mask.shape)
            lookup = cKDTree(points)
            dist, nearest = lookup.query(np.column_stack((xx.ravel(), yy.ravel())))
            covered = dist.reshape(mask.shape) < np.maximum(4., radii[nearest].reshape(mask.shape)*.70)
            allow &= ~covered
    return candidates


def _deduplicate(candidates, limit):
    selected = []
    for candidate in sorted(candidates, key=lambda item: -item['score']):
        points, radii = candidate['points'], candidate['radii']
        duplicate = False
        for existing in selected:
            if candidate['background'] != existing['background']:
                continue
            distances, _ = cKDTree(existing['points']).query(points)
            threshold = np.minimum(np.mean(radii), np.mean(existing['radii']))*.55+1.
            if np.mean(distances < threshold) > .73:
                duplicate = True
                break
        if not duplicate:
            selected.append(candidate)
        if len(selected) >= limit:
            break
    return selected


def _ordered(candidates, focus, diagonal):
    """Big masses first, then nearby connected movements, entirely data-derived."""
    remaining = list(candidates)
    result = []
    cursor = np.asarray(focus, float)
    for background in (True, False):
        pool = [item for item in remaining if item['background'] == background]
        while pool:
            score_scale = max(item['score'] for item in pool)
            def priority(item):
                near = min(np.linalg.norm(item['points'][0]-cursor),
                           np.linalg.norm(item['points'][-1]-cursor))/diagonal
                return item['score']/score_scale-.85*near
            chosen = max(pool, key=priority)
            pool = [item for item in pool if item is not chosen]
            points = chosen['points']
            if np.linalg.norm(points[-1]-cursor) < np.linalg.norm(points[0]-cursor):
                chosen = dict(chosen, points=points[::-1], radii=chosen['radii'][::-1])
            result.append(chosen)
            cursor = chosen['points'][-1]
    return result


def extract_guides(rgb, max_guides=48):
    """Return ``[(Nx2 points, N radii), ...]`` in source-pixel coordinates.

    Every movement, width and ordering decision is computed from input pixels.
    No remote model service is used. A bundled pretrained Haar face detector
    provides optional attention hints only. Portraits/full figures with
    complex backgrounds remain an experimental classical-vision use case.
    """
    source = np.asarray(rgb)
    if source.ndim != 3 or source.shape[2] < 3 or min(source.shape[:2]) < 8:
        raise ValueError('Expected an RGB image of at least 8 by 8 pixels')
    source = np.clip(source[..., :3], 0, 255).astype(np.uint8)
    h, w = source.shape[:2]
    scale = min(1., 384./max(h, w))
    working = cv2.resize(source, (max(8, round(w*scale)), max(8, round(h*scale))), interpolation=cv2.INTER_AREA)
    ah, aw = working.shape[:2]
    smooth = cv2.GaussianBlur(working, (0, 0), max(.8, min(ah, aw)*.007))
    lab = cv2.cvtColor(smooth.astype(np.float32)/255., cv2.COLOR_RGB2LAB)
    flat = lab.reshape(-1, 3)
    stride = max(1, len(flat)//18000)
    samples = flat[::stride].copy()
    cv2.setRNGSeed(7129)
    color_count = min(7, max(2, int(np.std(flat, axis=0).sum()/9.)+2))
    _, _, centers = cv2.kmeans(samples, color_count, None,
                            (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_MAX_ITER, 32, .12),
                            3, cv2.KMEANS_PP_CENTERS)
    differences = ((lab[:, :, None, :]-centers[None, None, :, :])**2).sum(axis=3)
    labels = differences.argmin(axis=2)
    border = np.zeros((ah, aw), bool)
    border_width = max(2, round(min(ah, aw)*.035))
    border[:border_width] = border[-border_width:] = True
    border[:, :border_width] = border[:, -border_width:] = True
    border_fractions = np.bincount(labels[border], minlength=color_count)/border.sum()
    bg_index = int(border_fractions.argmax())
    bg_rgb = np.median(smooth[labels == bg_index], axis=0)
    pale_background = bool(np.min(bg_rgb) > 238. and np.ptp(bg_rgb) < 17.)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    candidates = []
    for color in range(color_count):
        background = bool(border_fractions[color] > .24 and np.mean(labels == color) > .16)
        if background and pale_background and np.min(np.median(smooth[labels == color], axis=0)) > 238.:
            continue
        mask = (labels == color).astype(np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        candidates.extend(_candidate_paths(mask, f'low-frequency-colour-{color}', background, 3))
    # A second, overlapping scale joins neighboring pigments into broad masses.
    # It is an analysis hint only and is never exported as a clipping boundary.
    background_distance = np.sqrt(((lab-centers[bg_index])**2).sum(axis=2))
    if border_fractions[bg_index] > .40:
        threshold = max(8., float(np.percentile(background_distance[border], 60))+3.)
        activity = (background_distance > threshold).astype(np.uint8)
        activity = cv2.morphologyEx(activity, cv2.MORPH_CLOSE, kernel, iterations=2)
        candidates.extend(_candidate_paths(activity, 'overlapping-large-mass', False, 4))
    candidates = _deduplicate(candidates, max_guides)
    low_confidence = len(candidates) < 4
    if len(candidates) < 4:
        # An input with few visible axes still gets an image-driven full-canvas
        # lay-in, using the image covariance rather than a body-coordinate grid.
        gray = cv2.cvtColor(smooth, cv2.COLOR_RGB2GRAY)
        gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0)
        gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1)
        horizontal = float(np.mean(gx*gx)) > float(np.mean(gy*gy))
        bands = 4
        for i in range(bands):
            if horizontal:
                x = aw*(i+.5)/bands
                points = np.column_stack((np.full(7, x), np.linspace(0, ah-1, 7)))
                radii = np.full(7, aw/(bands*1.7))
            else:
                y = ah*(i+.5)/bands
                points = np.column_stack((np.linspace(0, aw-1, 7), np.full(7, y)))
                radii = np.full(7, ah/(bands*1.7))
            candidates.append(dict(points=points, radii=radii,
                                   length=float(max(aw, ah)), area=aw*ah//bands,
                                   background=True, origin='low-confidence-whole-canvas',
                                   score=float(aw*ah/bands)))
    # Face detection is a pixel-derived attention hint, never a body template.
    face_boxes = []
    cascade_path = getattr(cv2, 'data', None)
    if cascade_path is not None and hasattr(cv2, 'CascadeClassifier'):
        detector = cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
        if not detector.empty():
            face_boxes = detector.detectMultiScale(cv2.cvtColor(working, cv2.COLOR_RGB2GRAY),
                                                   scaleFactor=1.15, minNeighbors=5,
                                                   minSize=(max(18, aw//15), max(18, ah//15)))
    face_boxes = np.asarray(face_boxes).reshape(-1, 4)
    if len(face_boxes):
        box = face_boxes[np.argmax(face_boxes[:, 2]*face_boxes[:, 3])]
        focus = box[:2]+box[2:]*.5
    elif candidates:
        biggest = max(candidates, key=lambda item: item['score'] if not item['background'] else 0.)
        focus = np.mean(biggest['points'], axis=0)
    else:
        focus = np.array([aw/2., ah/2.])
    ordered = _ordered(candidates, focus, math.hypot(aw, ah))
    sx, sy = w/aw, h/ah
    gestures, descriptions = [], []
    for index, item in enumerate(ordered):
        points = item['points']*np.array([sx, sy])
        radii = item['radii']*math.sqrt(sx*sy)
        gestures.append((np.round(points, 3).tolist(), np.round(radii, 3).tolist()))
        descriptions.append(dict(index=index, origin=item['origin'], background=item['background'],
                                 length=round(item['length']*math.sqrt(sx*sy), 2),
                                 meanRadius=round(float(radii.mean()), 2),
                                 score=round(item['score'], 2)))
    metadata = dict(method='automatic low-frequency colour masses and medial open axes',
                    sourceSize=[w, h], analysisSize=[aw, ah], guideCount=len(gestures),
                    manualCoordinateCount=0, sourceSpecificRules=False,
                    ordering='broad background first; visual mass and endpoint proximity',
                    paintClipping=False, semanticPoseRecognition=False,
                    lowConfidence=bool(low_confidence), paleBackground=pale_background,
                    faceAttentionHints=(face_boxes*np.array([sx, sy, sx, sy])).round(2).tolist(),
                    guides=descriptions,
                    limitation='Classical image structure only; not anatomical pose or occlusion understanding.')
    return gestures, metadata


"""Develop one open gesture until its large form is supported by the canvas.

An episode is an interval of attention, not an image segment. All measurements
are one-dimensional samples along/normal to an open guide. They never become a
closed boundary, a clipping path, or a map of pixel ownership. Every accepted
physical brush footprint is painted in full by the supplied painter.
"""
import math
from collections import Counter

import cv2
import numpy as np
from scipy.ndimage import gaussian_filter1d


def _frame(points):
    tangent = np.gradient(points, axis=0)
    tangent /= np.linalg.norm(tangent, axis=1)[:, None] + 1.e-9
    return np.column_stack((-tangent[:, 1], tangent[:, 0]))


def _sample(image, points):
    return cv2.remap(image.astype(np.float32), points[..., 0].astype(np.float32),
                     points[..., 1].astype(np.float32), cv2.INTER_LINEAR,
                     borderMode=cv2.BORDER_REPLICATE)


def _probes(points, radii):
    distance = np.r_[0., np.cumsum(np.linalg.norm(np.diff(points, axis=0), axis=1))]
    count = max(12, min(90, int(distance[-1] / 10) + 1))
    locations = np.linspace(distance[-1]*.035, distance[-1]*.965, count)
    center = np.column_stack([np.interp(locations, distance, points[:, axis]) for axis in (0, 1)])
    rr = np.interp(locations, distance, radii)
    # Loaded-brush end caps must not determine the anatomical sampling scale.
    rr = np.maximum(rr, np.percentile(radii, 60)*.32)
    normal = _frame(center)
    offsets = np.linspace(-1.30, 1.30, 35)
    samples = center[:, None, :] + normal[:, None, :]*rr[:, None, None]*offsets[None, :, None]
    return center, rr, normal, offsets, samples, locations


def _profile(image, samples):
    values = _sample(image, samples)
    values = gaussian_filter1d(values, 1.2, axis=1, mode='nearest')
    return gaussian_filter1d(values, .65, axis=0, mode='nearest')


def _longest_fraction(good, positions):
    if len(good) < 2:
        return float(bool(good.all()))
    weights = np.r_[np.diff(positions), np.diff(positions)[-1]]
    longest = current = 0.
    for valid, weight in zip(good, weights):
        current = current + weight if valid else 0.
        longest = max(longest, current)
    return float(longest / max(1.e-9, weights.sum()))


def _assessment(canvas, target_profile, samples, offsets, positions, layer=1):
    sigma = 16. if layer == 0 else 6. if layer == 1 else 3.
    actual = _profile(cv2.GaussianBlur(canvas, (0, 0), sigma), samples)
    weights = np.exp(-.5*(offsets/.85)**2)
    error = np.average(np.abs(actual-target_profile).mean(axis=2), axis=1, weights=weights)
    baseline = np.average(np.abs(255.-target_profile).mean(axis=2), axis=1, weights=weights)
    progress = 1.-error/(baseline+4.)
    good = (error <= (16. if layer == 0 else 11.)) | (progress >= (.75 if layer == 0 else .78))
    source_luma = target_profile @ np.array([.2126, .7152, .0722])
    actual_luma = actual @ np.array([.2126, .7152, .0722])
    derivative = np.diff(source_luma, axis=1)
    painted_derivative = np.diff(actual_luma, axis=1)
    amplitude = np.ptp(source_luma, axis=1)
    meaningful = amplitude >= 16.
    dot = (derivative*painted_derivative).sum(axis=1)
    correlation = dot/(np.linalg.norm(derivative, axis=1)*
                     np.linalg.norm(painted_derivative, axis=1)+1.e-6)
    contrast_error = np.abs(np.ptp(actual_luma, axis=1)-amplitude)
    structural_good = (correlation >= .52) & (contrast_error <= np.maximum(14., amplitude*.48))
    structure_fraction = float(structural_good[meaningful].mean()) if meaningful.any() else 1.
    fraction = float(good.mean())
    longest = _longest_fraction(good, positions)
    # This is explicitly a source/canvas profile proxy, not semantic vision.
    readable = (fraction >= .78 and longest >= .55 and
                float(error.mean()) <= (17. if layer == 0 else 13.5) and
                structure_fraction >= (.40 if layer == 0 else .58))
    return dict(readableProxy=bool(readable), meanProfileMAE=float(error.mean()),
                stationFractionReady=fraction, longestContinuousFraction=longest,
                meanWhiteErrorReduction=float(progress.mean()),
                meaningfulContrastStations=int(meaningful.sum()),
                contrastCorrespondence=structure_fraction,
                meanSignedGradientAgreement=float(correlation[meaningful].mean()) if meaningful.any() else None)


def _fit_open_movement(source, points, radii):
    """Move brush centers and loads using normal-profile activity moments.

    These are per-station brush parameters. No left/right silhouette is traced
    or joined, and the image remains equally paintable on either side.
    """
    normal = _frame(points)
    relative = np.linspace(-2.15, 2.15, 57)
    query = points[:, None, :] + normal[:, None, :]*radii[:, None, None]*relative[None, :, None]
    values = _profile(source, query)
    signal = np.linalg.norm(255.-values, axis=2)/math.sqrt(3.)
    activity = 1.-np.exp(-np.maximum(0., signal-4.)/22.)
    weights = activity*np.exp(-.5*(relative[None, :]/1.25)**2)
    mass = weights.sum(axis=1)
    mean = (weights*relative).sum(axis=1)/np.maximum(1.e-6, mass)
    variance = (weights*(relative[None, :]-mean[:, None])**2).sum(axis=1)/np.maximum(1.e-6, mass)
    step = float(np.median(np.linalg.norm(np.diff(points, axis=0), axis=1)))
    along_sigma = 30./max(1., step)
    shift = gaussian_filter1d(np.clip(mean, -.85, .85), along_sigma, mode='nearest')
    width = gaussian_filter1d(np.clip(np.sqrt(3.*variance)*.88, .38, 1.15), along_sigma, mode='nearest')
    # The tiny pressure cap follows its neighboring loaded movement.
    cap = np.minimum(1., radii/max(1., float(np.percentile(radii, 60))*.35))
    shifted = points+normal*(shift*radii*cap)[:, None]
    return shifted, radii*width, dict(maxCenterShift=float(np.max(np.abs(shift*radii))),
                                      widthFactorRange=[float(width.min()), float(width.max())])


def _fit_color_load(target, path, radii, color):
    """Fit one open brush load to its low-frequency normal color profiles.

    Color-compatible widths are brush parameters only. Two sides are never
    exported as a body outline, nor used to suppress any footprint pixels.
    """
    normal = _frame(path)
    relative = np.linspace(-1.45, 1.45, 37)
    query = path[:, None, :]+normal[:, None, :]*radii[:, None, None]*relative[None, :, None]
    values = _profile(target, query)
    error = np.linalg.norm(values-np.asarray(color), axis=2)/math.sqrt(3.)
    # A continuous dynamic program follows a paintable plane through the open
    # strip. Its position prior prevents chasing an unrelated nearby surface.
    local = error**2+relative[None, :]**2*95.
    transition = (relative[:, None]-relative[None, :])**2*850.
    back = np.empty(local.shape, dtype=np.int16)
    cost = local[0]
    for row in range(1, len(path)):
        combined = cost[:, None]+transition
        previous = combined.argmin(axis=0)
        back[row] = previous
        cost = local[row]+combined[previous, np.arange(len(relative))]
    selected = np.empty(len(path), dtype=int)
    selected[-1] = int(cost.argmin())
    for row in range(len(path)-1, 0, -1):
        selected[row-1] = back[row, selected[row]]
    left, right = np.empty(len(path)), np.empty(len(path))
    quality = error[np.arange(len(path)), selected]
    for row, column in enumerate(selected):
        tolerance = max(13., min(30., float(error[row, column])+7.))
        lo = hi = int(column)
        while lo and error[row, lo-1] <= tolerance:
            lo -= 1
        while hi < len(relative)-1 and error[row, hi+1] <= tolerance:
            hi += 1
        left[row], right[row] = relative[lo], relative[hi]
    step = float(np.median(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    raw_width = np.maximum(0., (right-left)*.50)
    displacement = gaussian_filter1d((left+right)*.5, 18./max(1., step), mode='nearest')
    load_width = gaussian_filter1d(raw_width, 20./max(1., step), mode='nearest')
    fitted = path+normal*(displacement*radii)[:, None]
    fitted_radii = np.maximum(.7, radii*load_width)
    # A color absent for a sustained length cannot be joined by a fabricated
    # hairline. Keep the longest compatible open interval of this brush load.
    can_load = (quality < 39.) & (raw_width*radii >= np.maximum(2.4, radii*.22))
    good = gaussian_filter1d(can_load.astype(float), .65) >= .55
    runs, start = [], None
    for index, valid in enumerate(np.r_[good, False]):
        if valid and start is None:
            start = index
        elif not valid and start is not None:
            runs.append((start, index)); start = None
    if not runs:
        return None
    start, stop = max(runs, key=lambda pair: pair[1]-pair[0])
    if stop-start < 3:
        return None
    fitted, fitted_radii = fitted[start:stop], fitted_radii[start:stop]
    distance = np.r_[0., np.cumsum(np.linalg.norm(np.diff(fitted, axis=0), axis=1))]
    if distance[-1] < 32.:
        return None
    # A new fragment lands with paint already loaded. It does not grow a long
    # hairline into a fat head or connect through a color-incompatible interval.
    cap = .55+.45*np.clip(np.minimum(distance, distance[-1]-distance)/22., 0., 1.)
    fitted_radii = fitted_radii*cap
    for index in range(1, len(fitted_radii)):
        fitted_radii[index] = min(fitted_radii[index], fitted_radii[index-1]+.30*(distance[index]-distance[index-1]))
    for index in range(len(fitted_radii)-2, -1, -1):
        fitted_radii[index] = min(fitted_radii[index], fitted_radii[index+1]+.30*(distance[index+1]-distance[index]))
    nn = _frame(fitted)
    fitted = np.round(fitted, 3)
    return fitted, fitted_radii, np.round(fitted+nn*fitted_radii[:, None], 3), np.round(fitted-nn*fitted_radii[:, None], 3)


def _adaptive_radii(source, points, radii):
    """Use normal low-frequency contrast to soften width, never cut a stroke."""
    normal = _frame(points)
    relative = np.linspace(-1.05, 1.05, 27)
    samples = points[:, None, :] + normal[:, None, :]*radii[:, None, None]*relative[None, :, None]
    profile = _profile(source, samples)
    differences = np.linalg.norm(np.diff(profile, axis=1), axis=2)
    center = len(relative)//2
    factors = np.ones(len(points))
    for index, row in enumerate(differences):
        threshold = max(8., float(np.percentile(row, 75))*1.5)
        peaks = np.flatnonzero(row > threshold)
        if len(peaks):
            distance = np.min(np.abs(peaks-center+.5))/center
            # Interior folds cannot collapse a large plane into little dots.
            factors[index] = np.clip(distance*1.15, .46, 1.)
    factors = gaussian_filter1d(factors, 1.5, mode='nearest')
    return radii*factors


def _segments(points, radii, source, maximum=320., minimum=95.):
    """Overlapping long color-load intervals along a single open movement."""
    distance = np.r_[0., np.cumsum(np.linalg.norm(np.diff(points, axis=0), axis=1))]
    colors = gaussian_filter1d(_sample(source, points[:, None, :])[:, 0, :], 2., axis=0, mode='nearest')
    result, start = [], 0
    while start < len(points)-2:
        last = start+1
        for stop in range(start+2, len(points)):
            length = distance[stop]-distance[start]
            last = stop
            color_span = np.linalg.norm(colors[stop]-colors[start])
            if length >= maximum or (length >= minimum and color_span > 44.):
                break
        if last-start >= 2:
            result.append((start, last+1))
        if last >= len(points)-1:
            break
        # Neighboring long marks overlap longitudinally instead of leaving
        # disconnected stamps when the brush load needs to change.
        desired = distance[last]-max(22., float(np.median(radii[start:last+1]))*.8)
        start = max(start+1, int(np.searchsorted(distance, desired)))
    return result or [(0, len(points))]


def _geometry(points, radii, lane, width_factor, begin, end):
    normal = _frame(points)
    path = points[begin:end] + normal[begin:end]*radii[begin:end, None]*lane
    rr = radii[begin:end]*width_factor
    if len(path) < 3:
        return None
    # Local segment caps are physical pressure/geometry, not hidden clipping.
    cap = np.interp(np.linspace(0, 1, len(path)), [0, .08, .90, 1], [.38, 1., 1., .30])
    rr = np.maximum(.65, rr*cap)
    path = np.round(path, 3)
    nn = _frame(path)
    left = np.round(path+nn*rr[:, None], 3)
    right = np.round(path-nn*rr[:, None], 3)
    return path, rr, left, right


def _proposal(painter, template, points, radii, target, palette_size):
    geometry = _geometry(points, radii, *template['geometry'])
    if geometry is None:
        return None
    path, rr, left, right = geometry
    footprint = painter.footprint(left, right)
    if footprint is None:
        return None
    (x0, y0, x1, y1), alpha = footprint
    area = float(alpha.sum())
    if area < 2.:
        return None
    truth = target[y0:y1, x0:x1].astype(float)
    wanted = (truth*alpha[:, :, None]).sum(axis=(0, 1))/area
    color, source_sample = painter.choose_color(wanted, None, palette_size)
    if template.get('fitLoad', True):
        geometry = _fit_color_load(target, path, rr, color)
        if geometry is None:
            return None
        path, rr, left, right = geometry
        footprint = painter.footprint(left, right)
        if footprint is None:
            return None
        (x0, y0, x1, y1), alpha = footprint
        area = float(alpha.sum())
        truth = target[y0:y1, x0:x1].astype(float)
    old = painter.canvas[y0:y1, x0:x1].astype(float)
    opacity = template['opacity']
    new = old*(1-alpha[:, :, None]*opacity)+np.asarray(color)*alpha[:, :, None]*opacity
    # Protect correct light surroundings softly. The entire brush is accepted
    # or rejected, and no pixels within the footprint are selectively removed.
    old_error = ((old-truth)**2).mean(axis=2)
    protection = 1.+2.*np.exp(-old_error/70.)*(truth.mean(axis=2)/255.)**10
    gain = float((((old-truth)**2-(new-truth)**2)*protection[:, :, None]).sum())
    if gain <= max(10., area*1.8):
        return None
    length = float(np.linalg.norm(np.diff(path, axis=0), axis=1).sum())
    return dict(points=path, radii=rr, color=color, sourceSample=source_sample,
                footprint=footprint, gain=gain, area=area, length=length,
                priority=gain/(area**.45)*(1.+min(1., length/240.)*.22))


def _coarse_progress(before, after):
    """Pixel gain alone must not purchase a worse large plane or turn."""
    keys = ('stationFractionReady', 'longestContinuousFraction', 'contrastCorrespondence')
    if after['meanProfileMAE'] > before['meanProfileMAE'] + 1.e-7:
        return 0.
    if any(after[key] < before[key] - 1.e-7 for key in keys):
        return 0.
    return (before['meanProfileMAE'] - after['meanProfileMAE'] +
            sum(6. * (after[key] - before[key]) for key in keys))


def _preview_assessment(painter, proposal, opacity, target_profile, samples, offsets, positions, layer):
    trial = painter.canvas.copy()
    (x0, y0, x1, y1), alpha = proposal['footprint']
    alpha = alpha[:, :, None] * opacity
    trial[y0:y1, x0:x1] = np.rint(trial[y0:y1, x0:x1] * (1.-alpha) +
                                 np.asarray(proposal['color']) * alpha).astype(np.uint8)
    return _assessment(trial, target_profile, samples, offsets, positions, layer)


def _repair_templates(canvas, target_profile, samples, offsets, positions, points, radii, current, layer):
    """Read the unresolved open profile, then choose a broad load or its turn.

    The interval and lanes are brush parameters, never a closed paint region.
    Re-read after each accepted movement; do not replay the whole episode.
    """
    sigma = 16. if layer == 0 else 6.
    actual = _profile(cv2.GaussianBlur(canvas, (0, 0), sigma), samples)
    residual = np.abs(actual-target_profile).mean(axis=2)
    station_error = residual.mean(axis=1)
    anchor = int(np.argmax(gaussian_filter1d(station_error, 1., mode='nearest')))
    distance = np.r_[0., np.cumsum(np.linalg.norm(np.diff(points, axis=0), axis=1))]
    span = max(65., min(distance[-1], float(np.median(radii))*4., distance[-1]*.65))
    begin = max(0, int(np.searchsorted(distance, positions[anchor]-span*.5))-1)
    end = min(len(points), max(begin+3, int(np.searchsorted(distance, positions[anchor]+span*.5))+1))
    chunks = list(dict.fromkeys([(begin, end), (0, len(points))]))
    plane_missing = (current['stationFractionReady'] < .78 or current['longestContinuousFraction'] < .55 or
                     current['meanProfileMAE'] > (17. if layer == 0 else 13.5))
    intent = 'plane' if plane_missing else 'turn'
    # The worst normal-profile deficit locates the side to load. Width is
    # broad relative to the existing guide; it never collapses into pixel dabs.
    across = gaussian_filter1d(residual[max(0, anchor-1):anchor+2].mean(axis=0), 2.)
    lane = float(np.clip(offsets[int(across.argmax())], -.95, .95))
    lanes = [(lane, .68), (0., .90), (-.48, .62), (.48, .62)] if plane_missing else [(lane, .40), (-.65, .38), (.65, .38)]
    templates = [dict(geometry=(offset, width, start, stop), intent=intent, opacity=.97,
                      fitLoad=False, repairRole='main_plane_width' if plane_missing else 'turn_lane')
                 for start, stop in chunks for offset, width in lanes]
    # Also consider a colour-compatible turn, but keep the broad untrimmed
    # alternatives available when fitting would shrink a main plane away.
    templates += [dict(geometry=(lane, .55, start, stop), intent=intent, opacity=.97,
                       fitLoad=True, repairRole='colour_load_width') for start, stop in chunks]
    return templates


def paint_construction_episode(painter, guide_index, layer=1, palette_size=28,
                               max_strokes=None, max_rounds=None, profile_only=False, feedback=None):
    """Paint one variable-length construction episode; return honest evidence.

    Required painter API: src, canvas, guides[(Nx2 points,N radii)],
    footprint(left,right), choose_color(target,xy,n), and
    put(points,radii,color,sample,layer,intent,opacity,group,proposal).

    Readable proxy => leave; budget => unfinished/revisit; no improvement =>
    unfinished/revisit. No fixed ten-stroke completion rule is used. The proxy
    concerns large planes and cross-sectional structure, not finished detail.
    ``profile_only`` measures the current canvas without painting.
    """
    if not 0 <= guide_index < len(painter.guides):
        raise ValueError('Unknown open guide index')
    original_points, original_radii = painter.guides[guide_index]
    points = np.asarray(original_points, dtype=float).copy()
    provided_radii = np.asarray(original_radii, dtype=float).copy()
    if len(points) < 3 or provided_radii.shape != (len(points),):
        raise ValueError('An open guide needs at least three points and matching radii')
    if not np.isfinite(points).all() or not np.isfinite(provided_radii).all():
        raise ValueError('Guide geometry must be finite')
    max_strokes = (14 if layer == 0 else 48) if max_strokes is None else max_strokes
    max_rounds = (1 if layer == 0 else 2) if max_rounds is None else max_rounds
    sigma = 16. if layer == 0 else 6. if layer == 1 else 3.
    target = cv2.GaussianBlur(painter.src, (0, 0), sigma)
    if getattr(painter, 'auto_guides', False):
        fitted_radii=provided_radii.copy()
        movement_fit=dict(mode='automatic image-derived geometry; no white-background refit')
    else:
        points, fitted_radii, movement_fit = _fit_open_movement(target, points, provided_radii)
    if layer == 0:
        # Build the main plane as broad, smooth, uninterrupted paint first.
        # Fine color compatibility is deliberately irrelevant at this stage.
        step = float(np.median(np.linalg.norm(np.diff(points, axis=0), axis=1)))
        points = gaussian_filter1d(points, 22./max(1., step), axis=0, mode='nearest')
        radii = gaussian_filter1d(fitted_radii, 25./max(1., step), mode='nearest')
    else:
        radii = _adaptive_radii(target, points, fitted_radii)
    center, probe_radii, normal, offsets, samples, positions = _probes(points, radii)
    target_profile = _profile(target, samples)
    before = _assessment(painter.canvas, target_profile, samples, offsets, positions, layer)
    start_index = len(painter.strokes)
    report = dict(guideIndex=int(guide_index), layer=int(layer), startIndex=start_index,
                  before=before, history=[], accepted=0, attempted=0, rounds=0,
                  intentCounts={}, acceptedLengths=[], acceptedWidths=[], rejectedCoarse=0,
                  movementFit=movement_fit,
                  actualEvalSigma=sigma,
                  geometry='open longitudinal sweeps; whole physical brush footprints',
                  completionMeaning='Measured large-plane/profile correspondence only; not semantic recognition or finished detail.')
    if profile_only or before['readableProxy']:
        report.update(status='readable_proxy' if before['readableProxy'] else 'measure_only',
                      needsRevisit=not before['readableProxy'], after=before, endIndex=start_index)
        return report

    segments = _segments(points, radii, target)
    intents = Counter()
    status = 'no_improvement'
    episode_number = int(getattr(painter, '_construction_episode_count', 0))
    painter._construction_episode_count = episode_number+1
    group = f'construction-{layer}-{episode_number}'
    current = before
    if feedback is not None:
        if feedback['guideIndex'] != guide_index or feedback['layer'] != layer or not feedback['needsRevisit']:
            raise ValueError('Repair feedback must describe this unfinished open movement')
        report['feedbackConsumed'] = dict(status=feedback['status'], after=feedback['after'])
        report['repairActions'] = []
        # Same five-mark continuation ceiling as v7.0, with a finite candidate
        # search and an explicit stall. No additional rounds or detail pass.
        for _ in range(min(max_strokes, 5)):
            candidates = []
            for template in _repair_templates(painter.canvas, target_profile, samples, offsets, positions,
                                               points, radii, current, layer):
                report['attempted'] += 1
                proposal = _proposal(painter, template, points, radii, target, palette_size)
                if proposal is None:
                    continue
                assessment = _preview_assessment(painter, proposal, template['opacity'], target_profile,
                                                 samples, offsets, positions, layer)
                progress = _coarse_progress(current, assessment)
                if progress < .08:
                    report['rejectedCoarse'] += 1
                    continue
                candidates.append((progress, proposal, template, assessment))
            if not candidates:
                status = 'no_improvement'
                report['stopReason'] = 'no_safe_coarse_progress_on_current_open_axis'
                break
            _, proposal, template, assessment = max(candidates, key=lambda item: item[0])
            if not painter.put(proposal['points'], proposal['radii'], proposal['color'], proposal['sourceSample'],
                               layer, template['intent'], template['opacity'], group, proposal['footprint']):
                status = 'no_improvement'
                report['stopReason'] = 'brush_not_paintable'
                break
            current = assessment
            report['accepted'] += 1
            intents[template['intent']] += 1
            report['acceptedLengths'].append(proposal['length'])
            report['acceptedWidths'].append(float(2*proposal['radii'].max()))
            report['repairActions'].append(dict(role=template['repairRole'], geometry=list(template['geometry'])))
            report['history'].append(dict(afterAccepted=report['accepted'], intent=template['intent'], **current))
            if current['readableProxy']:
                status = 'readable_proxy'
                report['stopReason'] = 'coarse_profile_ready'
                break
        else:
            status = 'budget_unfinished'
            report['stopReason'] = 'bounded_repair_budget'
        report.update(status=status, needsRevisit=status != 'readable_proxy', after=current,
                      endIndex=len(painter.strokes), intentCounts=dict(intents))
        return report
    for round_index in range(max_rounds):
        report['rounds'] += 1
        scale = 1. if round_index == 0 else .78 if round_index == 1 else .58
        chunks = [(0, len(points))] if round_index == 0 else []
        chunks += segments
        # Main planes are developed first, then adjacent turns, then open
        # environmental corrections. These are brush lanes, not image borders.
        phases = [
            ('plane', [(0., .67), (-.46, .54), (.46, .54)], .97),
            ('turn', [(-.76, .33), (.76, .33), (-.25, .28), (.25, .28)], .92),
            ('plane', [(-1.08, .29), (1.08, .29)], .97),
        ]
        accepted_this_round = 0
        for phase_number, (intent, lanes, opacity) in enumerate(phases):
            phase_chunks = [(0, len(points))] if layer == 0 and phase_number == 0 else chunks
            if layer == 0 and phase_number == 1:
                lanes = [(-.60, .38), (.60, .38)]
            templates = [dict(geometry=(lane, width*scale, begin, end), intent=intent,
                              opacity=opacity, fitLoad=not(layer == 0 and phase_number == 0))
                         for begin, end in phase_chunks for lane, width in lanes]
            accepted_in_phase = 0
            while templates:
                if report['accepted'] >= max_strokes:
                    status = 'budget_unfinished'; break
                # Read current canvas again: residual rejection cannot silently
                # turn a planned long movement into three isolated accepted dabs.
                candidates = []
                for index, template in enumerate(templates):
                    proposal = _proposal(painter, template, points, radii, target, palette_size)
                    report['attempted'] += 1
                    if proposal is not None:
                        candidates.append((proposal['priority'], -index, index, proposal))
                if not candidates:
                    break
                _, _, index, proposal = max(candidates, key=lambda value: (value[0], value[1]))
                template = templates.pop(index)
                assessed = _preview_assessment(painter, proposal, template['opacity'], target_profile,
                                               samples, offsets, positions, layer)
                if _coarse_progress(current, assessed) < .02:
                    report['rejectedCoarse'] += 1
                    continue
                accepted = painter.put(proposal['points'], proposal['radii'], proposal['color'],
                                       proposal['sourceSample'], layer, template['intent'],
                                       template['opacity'], group, proposal['footprint'])
                if not accepted:
                    continue
                report['accepted'] += 1; accepted_this_round += 1
                accepted_in_phase += 1
                intents[template['intent']] += 1
                report['acceptedLengths'].append(proposal['length'])
                report['acceptedWidths'].append(float(2*proposal['radii'].max()))
                current = assessed
                report['history'].append(dict(afterAccepted=report['accepted'], intent=template['intent'], **current))
                turn_required = current['meaningfulContrastStations'] >= max(3, len(positions)*.25)
                if current['readableProxy'] and (not turn_required or intents['turn'] >= 1):
                    status = 'readable_proxy'; break
                if (phase_number == 0 and current['stationFractionReady'] >= .76 and
                        current['longestContinuousFraction'] >= .55):
                    # Main plane is continuous: proceed to its major turn now,
                    # instead of exhausting all same-axis color refinements.
                    break
                if layer == 0 and accepted_in_phase >= (3 if phase_number != 1 else 4):
                    # A coarse episode has a small work budget per paint role.
                    # Running out is unfinished, never a completion criterion.
                    break
            if status in ('readable_proxy', 'budget_unfinished'):
                break
        if status in ('readable_proxy', 'budget_unfinished'):
            break
        if accepted_this_round == 0:
            status = 'no_improvement'; break
        status = 'budget_unfinished' if round_index == max_rounds-1 else 'no_improvement'
    report.update(status=status, needsRevisit=status != 'readable_proxy', after=current,
                  endIndex=len(painter.strokes), intentCounts=dict(intents),
                  guideLength=float(np.linalg.norm(np.diff(points, axis=0), axis=1).sum()),
                  radiusRatioRange=[float(np.min(radii/np.maximum(provided_radii, .001))),
                                    float(np.max(radii/np.maximum(provided_radii, .001)))])
    return report


"""Paint one shared canvas: global gestures, value, volume, then detail.

No semantic polygons, source-region clipping, ownership maps or source-image
reveals are used. Automatically extracted open compositional gestures guide the broad movement;
colour, local structure and correction decisions are read from the reference.
Dependencies: numpy scipy opencv-python Pillow.
python build_portrait.py --source IMAGE --work-dir generated --through 1
python build_portrait.py --source IMAGE --work-dir generated --through 4
"""
from pathlib import Path
import argparse
import base64
import io
import json
import math
import pickle
import time
import cv2
import numpy as np
from scipy.spatial import cKDTree
from scipy.ndimage import gaussian_filter1d
from PIL import Image, ImageDraw, ImageOps

ROOT=Path(__file__).resolve().parent
OUT,QA=ROOT/'output',ROOT/'qa'
VERSION='7.2'
cv2.setNumThreads(1)
STAGES=('composition','value','volume','detail')
PHASES=[('连贯底形','顺着开放走势铺通主面，再建立主要转折'),
        ('大面明暗','留在当前走势调整明暗与边缘，再继续下一段'),
        ('体积冷暖','沿软走势塑造转折，允许跨越早期笔缘修形'),
        ('焦点细节','整体成立后加入线条、材质和少量点笔')]
INTENT_LABELS=dict(silhouette='整体主势',plane='大面铺色',turn='体积转折',edge='边缘与线条',accent='反光与点笔')


def image_url(rgb,width=480):
    image=Image.fromarray(rgb);image.thumbnail((width,2000),Image.Resampling.LANCZOS)
    stream=io.BytesIO();image.save(stream,format='JPEG',quality=93)
    return 'data:image/jpeg;base64,'+base64.b64encode(stream.getvalue()).decode()


def resample(points,radii,step=7):
    p=np.asarray(points,float);r=np.asarray(radii,float)
    d=np.r_[0,np.cumsum(np.linalg.norm(np.diff(p,axis=0),axis=1))]
    t=np.linspace(0,d[-1],max(3,int(d[-1]/step)+1))
    q=np.column_stack([np.interp(t,d,p[:,i]) for i in range(2)])
    rr=np.interp(t,d,r)
    if len(q)>6:
        q=gaussian_filter1d(q,2.,axis=0,mode='nearest')
        rr=gaussian_filter1d(rr,1.4,mode='nearest')
    # A short loaded-brush cap, expressed as additional travelled geometry.
    # It is not a hidden full outline and never exposes a future fat section.
    entry=q[1]-q[0];entry/=np.linalg.norm(entry)+1e-9
    exit_axis=q[-1]-q[-2];exit_axis/=np.linalg.norm(exit_axis)+1e-9
    q=np.r_[[q[0]-entry*rr[0]*.62,q[0]-entry*rr[0]*.35],q,
            [q[-1]+exit_axis*rr[-1]*.35,q[-1]+exit_axis*rr[-1]*.62]]
    rr=np.r_[rr[0]*.08,rr[0]*.72,rr,rr[-1]*.72,rr[-1]*.08]
    return q,rr


def edges(points,radii):
    tangent=np.gradient(points,axis=0);tangent/=np.linalg.norm(tangent,axis=1)[:,None]+1e-9
    normal=np.column_stack((-tangent[:,1],tangent[:,0]))
    return np.round(points+normal*radii[:,None],3),np.round(points-normal*radii[:,None],3)


def path_d(left,right):
    return 'M'+' L'.join(f'{x:.3f},{y:.3f}' for x,y in np.r_[left,right[::-1]])+' Z'


class SharedCanvasPainter:
    def __init__(self,source,max_edge=768):
        original=ImageOps.exif_transpose(Image.open(source)).convert('RGBA')
        if min(original.size)<32:raise ValueError('Image must be at least 32 pixels on each side')
        original.thumbnail((max_edge,max_edge),Image.Resampling.LANCZOS)
        self.src=np.array(Image.alpha_composite(Image.new('RGBA',original.size,'white'),original).convert('RGB'))
        self.h,self.w=self.src.shape[:2];self.canvas=np.full_like(self.src,255)
        self.rng=np.random.default_rng(83177);self.strokes=[];self.layers=[];self.events=[];self.clock=0
        self.construction_reports=[]
        self.guides=[]
        gestures,self.guide_metadata=extract_guides(self.src)
        if not gestures:raise ValueError("No usable open movements were found in this image")
        self.auto_guides=True
        for p,r in gestures:
            pts=np.array(p,float);rad=np.array(r,float)
            pts,rad=resample(pts,rad)
            self.guides.append((pts,rad))
        allp=np.concatenate([p for p,r in self.guides]);allt=np.concatenate([np.gradient(p,axis=0) for p,r in self.guides])
        allt/=np.linalg.norm(allt,axis=1)[:,None]+1e-9
        self.guide_tree=cKDTree(allp);self.guide_vectors=allt
        yy,xx=np.mgrid[0:self.h:20,0:self.w:20];xy=np.column_stack((xx.ravel(),yy.ravel()))
        distances,indices=self.guide_tree.query(xy,k=min(8,len(allp)))
        if distances.ndim==1:distances=distances[:,None];indices=indices[:,None]
        v=self.guide_vectors[indices];angle=np.arctan2(v[:,:,1],v[:,:,0]);weights=np.exp(-(distances/155)**2)/(distances+12)
        z=(np.exp(2j*angle)*weights).sum(axis=1);a=.5*np.angle(z).reshape(xx.shape)
        self.flow_x=cv2.resize(np.cos(2*a).astype(np.float32),(self.w,self.h))
        self.flow_y=cv2.resize(np.sin(2*a).astype(np.float32),(self.w,self.h))
        gray=cv2.cvtColor(self.src,cv2.COLOR_RGB2GRAY).astype(np.float32)
        mean=cv2.GaussianBlur(gray,(0,0),2)
        self.contrast=np.sqrt(np.maximum(0,cv2.GaussianBlur(gray*gray,(0,0),2)-mean*mean))
        gx=cv2.Sobel(cv2.GaussianBlur(gray,(0,0),.6),cv2.CV_32F,1,0)
        gy=cv2.Sobel(cv2.GaussianBlur(gray,(0,0),.6),cv2.CV_32F,0,1)
        xx=cv2.GaussianBlur(gx*gx,(0,0),1.7);yy=cv2.GaussianBlur(gy*gy,(0,0),1.7);xy=cv2.GaussianBlur(gx*gy,(0,0),1.7)
        self.texture_angle=.5*np.arctan2(2*xy,xx-yy)+np.pi/2
        self.coherence=np.sqrt((xx-yy)**2+4*xy*xy)/(xx+yy+1e-8)
        self.edge_distance=cv2.distanceTransform(255-cv2.Canny(gray.astype(np.uint8),24,60),cv2.DIST_L2,3)
        self.palettes={};self.routes=[]

    def pixel(self,x,y):return int(np.clip(round(x),0,self.w-1)),int(np.clip(round(y),0,self.h-1))

    def palette(self,n):
        if n in self.palettes:return self.palettes[n]
        small=cv2.resize(self.src,(min(320,self.w),max(1,round(self.h*min(320,self.w)/self.w))))
        flat=small.reshape(-1,3);take=self.rng.choice(len(flat),min(26000,len(flat)),False)
        lab=cv2.cvtColor(flat[take][None].astype(np.float32)/255,cv2.COLOR_RGB2LAB)[0]
        cv2.setRNGSeed(83177+n)
        _,_,centers=cv2.kmeans(lab,n,None,(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_MAX_ITER,35,.08),2,cv2.KMEANS_PP_CENTERS)
        samples=np.column_stack((self.rng.integers(0,self.w,30000),self.rng.integers(0,self.h,30000)))
        rgb=self.src[samples[:,1],samples[:,0]]
        samplelab=cv2.cvtColor(rgb[None].astype(np.float32)/255,cv2.COLOR_RGB2LAB)[0]
        palette=[];coords=[]
        for center in centers:
            i=int(np.argmin(((samplelab-center)**2).sum(axis=1)));palette.append(rgb[i]);coords.append(samples[i].tolist())
        # White/near-white is real paint too: negative shapes can be corrected.
        white_index=np.unravel_index(np.argmax(self.src.sum(axis=2)),self.src.shape[:2])
        palette.append(self.src[white_index]);coords.append([int(white_index[1]),int(white_index[0])])
        result=np.array(palette),coords;self.palettes[n]=result;return result

    def choose_color(self,target,xy,n):
        colors,coords=self.palette(n);i=int(np.argmin(((colors.astype(float)-target)**2).sum(axis=1)))
        return colors[i].tolist(),coords[i]

    def footprint(self,left,right):
        polygon=np.r_[left,right[::-1]]
        x0,y0=np.maximum(0,np.floor(polygon.min(axis=0)).astype(int)-2)
        x1,y1=np.minimum([self.w,self.h],np.ceil(polygon.max(axis=0)).astype(int)+3)
        if x1<=x0 or y1<=y0:return None
        m=np.zeros(((y1-y0)*2,(x1-x0)*2),np.uint8)
        cv2.fillPoly(m,[np.rint((polygon-[x0,y0])*2).astype(np.int32)],255,cv2.LINE_AA)
        a=cv2.resize(m,(x1-x0,y1-y0),interpolation=cv2.INTER_AREA).astype(np.float32)/255
        return (x0,y0,x1,y1),a

    def put(self,points,radii,color,sample,layer,intent,opacity=1.,group=None,proposal=None):
        points=np.round(np.array(points,float),3);left,right=edges(points,np.array(radii))
        length=float(np.linalg.norm(np.diff(points,axis=0),axis=1).sum())
        if length<.1:return False
        crop=self.footprint(left,right) if proposal is None else proposal
        if crop is None:return False
        (x0,y0,x1,y1),a=crop;alpha=a[:,:,None]*opacity
        c=self.canvas[y0:y1,x0:x1];c[:]=np.rint(c*(1-alpha)+np.array(color)*alpha).astype(np.uint8)
        duration=round(np.clip(130+length*2.5,150,3300));pause=85 if intent not in ('accent','edge') else 100
        s=dict(d=path_d(left,right),left=left.tolist(),right=right.tolist(),points=points.tolist(),
               spine='M'+' L'.join(f'{x:g},{y:g}' for x,y in points),length=length,width=round(float(2*np.max(radii)),3),
               color='#'+''.join(f'{int(c):02x}' for c in color),opacity=opacity,start=self.clock,duration=duration,
               pauseAfter=pause,layer=layer,stage=STAGES[layer],phase=PHASES[layer][0],intent=intent,
               intentLabel=INTENT_LABELS[intent],group=group or f'{layer}-{len(self.strokes)//10}',
               colorSample=sample,sourceSample=sample,sample=sample,type='sweep' if length>12 else 'dab')
        self.strokes.append(s);self.clock+=duration+pause;return True

    def compose(self):
        return self.construction_sequence(0)

    def construction_sequence(self,layer):
        # This is a list of open drawing movements, not source regions. Nearby
        # complementary movements stay together; paint remains free to overlap.
        order=list(range(len(self.guides)))
        for i in order:
            report=paint_construction_episode(self,i,layer=layer,palette_size=12 if layer==0 else 28)
            self.construction_reports.append(report)
            print(json.dumps(dict(stage=STAGES[layer],guide=i,accepted=report['accepted'],status=report['status'],after=report['after']),ensure_ascii=False),flush=True)
            if report['needsRevisit']:
                # Stay on this movement for an immediate, more selective load.
                # A stalled continuation remains explicitly unresolved; it is
                # never labelled complete merely because a budget was spent.
                follow=paint_construction_episode(self,i,layer=layer,palette_size=28 if layer==0 else 96,
                                                  max_strokes=5,max_rounds=1,feedback=report)
                follow['continuationOf']=len(self.construction_reports)-1
                self.construction_reports.append(follow)
                print(json.dumps(dict(stage=STAGES[layer],guide=i,continuation=True,accepted=follow['accepted'],status=follow['status'],after=follow['after']),ensure_ascii=False),flush=True)
                report=follow
            # A move is now an explicit scheduling decision. Unresolved axes
            # stay visible with their stop reason; budget is never success.
            report['transitionDecision']=('proxy_ready' if not report['needsRevisit'] else
                                          'stalled_unresolved' if report['status']=='no_improvement' else
                                          'blocked_unresolved')
            if report['transitionDecision']=='blocked_unresolved':
                self.construction_blocked=dict(layer=layer,guideIndex=i,
                    reportIndex=len(self.construction_reports)-1,
                    reason='repair_budget_exhausted_before_coarse_ready')
                return False
        return True

    def direction(self,x,y,layer):
        ix,iy=self.pixel(x,y)
        theta=.5*math.atan2(float(self.flow_y[iy,ix]),float(self.flow_x[iy,ix]))
        if layer==3 and self.coherence[iy,ix]>.22:theta=float(self.texture_angle[iy,ix])
        v=np.array([math.cos(theta),math.sin(theta)])
        if v[1]<-.05:v=-v
        return v

    def gesture(self,x,y,width,length,layer,target,tolerance):
        center=np.array([x,y],float);initial=self.direction(x,y,layer)
        color=target[self.pixel(x,y)[1],self.pixel(x,y)[0]].astype(float)
        halves=[];step=max(.7,min(8.,width*.65))
        for sign in (-1,1):
            pos=center.copy();previous=initial*sign;chain=[]
            for _ in range(max(1,math.ceil(length/2/step))):
                v=self.direction(*pos,layer)
                if np.dot(v,previous)<0:v=-v
                v=.84*previous+.16*v;v/=np.linalg.norm(v)+1e-9
                if np.dot(v,initial*sign)<.55:v=previous
                nxt=pos+v*step
                if not(0<=nxt[0]<self.w and 0<=nxt[1]<self.h):break
                ix,iy=self.pixel(*nxt)
                if layer>=2 and np.max(np.abs(target[iy,ix].astype(float)-color))>tolerance:break
                chain.append(nxt.copy());pos=nxt;previous=v
            halves.append(chain)
        points=np.array(list(reversed(halves[0]))+[center]+halves[1])
        if len(points)<2:points=np.array([center-initial*.35,center+initial*.35])
        profile=np.interp(np.linspace(0,1,len(points)),[0,.12,.8,1],[.62,1,1,.50] if layer<3 else [.4,1,.95,.25])
        radii=profile*width/2
        if layer<3:
            points,radii=resample(points,radii,step=max(2.,width*.22))
        return points,radii

    def refine_pass(self,layer,extra=False):
        config={1:dict(sigma=11.,spacing=23.,maxw=62.,minw=16.,length=185.,error=10.,palette=28,opacity=.95,tolerance=999),
                2:dict(sigma=3.2,spacing=9.,maxw=23.,minw=5.5,length=90.,error=8.,palette=96,opacity=.9,tolerance=46),
                3:dict(sigma=0,spacing=3.5,maxw=7.,minw=1.0,length=32.,error=8.5,palette=None,opacity=1.,tolerance=24)}[layer]
        factor=max(.45,max(self.w,self.h)/1100.)
        for key in ('sigma','spacing','maxw','minw','length'):config[key]*=factor
        target=cv2.GaussianBlur(self.src,(0,0),config['sigma']) if config['sigma'] else self.src
        spacing=config['spacing']*(.76 if extra else 1.)
        ys,xs=np.mgrid[spacing*.3:self.h:spacing*.86,spacing*.3:self.w:spacing]
        seeds=np.column_stack((xs.ravel(),ys.ravel()))
        seeds+=self.rng.uniform(-.18,.18,seeds.shape)*spacing
        seeds=np.clip(seeds,[.1,.1],[self.w-1.1,self.h-1.1])
        ix=np.rint(seeds[:,0]).astype(int);iy=np.rint(seeds[:,1]).astype(int)
        errors=np.max(np.abs(self.canvas.astype(float)-target.astype(float)),axis=2)
        # All canvas positions, including white surroundings, remain eligible.
        valid=errors[iy,ix]>config['error']
        seeds=seeds[valid];initial=errors[iy[valid],ix[valid]]
        route,diag=attention_route(seeds,initial,self.w,self.h,window_radius=max(self.w,self.h)*(.20 if layer<3 else .15),bundle_size=10)
        summary={k:v for k,v in diag.items() if k not in ('bundles','bundleIds','relocations')};summary['stage']=STAGES[layer]
        self.routes.append(summary)
        accepted=0
        for position,index in enumerate(route):
            x,y=seeds[index];px,py=self.pixel(x,y)
            current_error=np.max(np.abs(self.canvas[py,px].astype(float)-target[py,px].astype(float)))
            if current_error<config['error']:continue
            width=min(config['maxw'],max(config['minw'],self.edge_distance[py,px]*(1.6 if layer<3 else 1.2)))
            length=config['length']*self.rng.uniform(.82,1.13)
            points,radii=self.gesture(x,y,width,length,layer,target,config['tolerance'])
            left,right=edges(points,radii);fp=self.footprint(left,right)
            if fp is None:continue
            (x0,y0,x1,y1),a=fp
            if config['palette']:
                # Fit the current load to a broad surface, but select an actual
                # original RGB sample from the global palette, never a region.
                weight=a.sum()
                wanted=(target[y0:y1,x0:x1]*a[:,:,None]).sum(axis=(0,1))/max(1,weight)
                center=target[py,px]
                if int(center.min())>246 and int(center.max())-int(center.min())<10:
                    wanted=np.array([255.,255.,255.])
                color,sample=self.choose_color(wanted,None,config['palette'])
            else:color=self.src[py,px].tolist();sample=[px,py]
            old=self.canvas[y0:y1,x0:x1].astype(float);truth=target[y0:y1,x0:x1].astype(float)
            alpha=a[:,:,None]*config['opacity'];new=old*(1-alpha)+np.array(color)*alpha
            before_error=((old-truth)**2).mean(axis=2)
            # A soft loss protects already correct light surroundings. The
            # entire physical brush is accepted or rejected; no pixels are cut.
            weight=1+4*np.exp(-before_error/60.)*(truth.mean(axis=2)/255.)**12 if layer in (1,2) else 1.
            gain=float((((old-truth)**2-(new-truth)**2)*
                        (weight[:,:,None] if isinstance(weight,np.ndarray) else weight)).sum())
            if gain<max(3.,a.sum()*1.8):continue
            intent='plane' if layer==1 else 'turn' if layer==2 else 'edge' if self.contrast[py,px]>8 else 'accent'
            group=f'{layer}-{int(diag["bundleIds"][position])}-{int(extra)}'
            self.put(points,radii,color,sample,layer,intent,config['opacity'],group,fp);accepted+=1
        print(json.dumps(dict(passStage=STAGES[layer],extra=extra,candidates=len(seeds),accepted=accepted)),flush=True)

    def low_frequency_evidence(self):
        result={}
        for sigma in (24,48):
            target=cv2.GaussianBlur(self.src.astype(np.float32),(0,0),sigma)
            painted=cv2.GaussianBlur(self.canvas.astype(np.float32),(0,0),sigma)
            baseline=float(np.abs(255-target).mean());mae=float(np.abs(painted-target).mean())
            result[f'sigma{sigma}']=dict(mae=round(mae,4),whiteBaseline=round(baseline,4),reduction=round(1-mae/max(.01,baseline),4))
        return result

    def paint_phase(self,layer):
        start=len(self.strokes);starttime=self.clock
        complete=True
        if layer==0:complete=self.compose()
        elif layer==1:
            complete=self.construction_sequence(1)
            if complete:self.refine_pass(1)
        else:self.refine_pass(layer)
        evidence=self.low_frequency_evidence()
        if layer==2 and min(v['reduction'] for v in evidence.values())<.62:
            self.refine_pass(layer,extra=True);evidence=self.low_frequency_evidence()
        if layer==3:
            # A final denser global pass restores small lines on the already
            # coherent painting, not tiny islands on untouched paper.
            self.refine_pass(3,extra=True)
            evidence=self.low_frequency_evidence()
        mae=float(np.abs(self.canvas.astype(float)-self.src.astype(float)).mean())
        info=dict(name=PHASES[layer][0],description=PHASES[layer][1],stage=STAGES[layer],startTime=starttime,complete=complete,
                  endTime=self.clock,endIndex=len(self.strokes),added=len(self.strokes)-start,mae=round(mae,4),
                  lowFrequency=evidence,previewDataURL=image_url(self.canvas))
        self.layers.append(info);self.events.append(dict(stage=STAGES[layer],start=starttime,end=self.clock))
        Image.fromarray(self.canvas).save(OUT/f'layer-{layer+1}.png')
        self.export();print(json.dumps(dict(layer=layer+1,added=info['added'],total=len(self.strokes),mae=mae,lowFrequency=evidence)),flush=True)
        return complete

    def export(self):
        report=validate_timeline(self.events,self.strokes,require_complete=len(self.layers)==4)
        data=dict(width=self.w,height=self.h,layers=self.layers,strokes=self.strokes,sourceDataURL=image_url(self.src,720),
                  totalDuration=self.clock,stageEvents=self.events,planValidation=report,constructionReports=self.construction_reports,
                  version=VERSION,constructionBlocked=getattr(self,'construction_blocked',None),
                  automaticGuides=self.guide_metadata,metrics=dict(totalPaths=len(self.strokes),sourceSize=[self.w,self.h],finalMAE=self.layers[-1]['mae'],
                  method='pixel-derived automatic open guides; shared canvas; no hand-authored coordinates; whole brush footprints',
                  brush='true growing ribbon geometry; unmasked paint can cross and cover earlier marks',routeDiagnostics=self.routes))
        (QA/'painting-data.json').write_text(json.dumps(data,separators=(',',':'),ensure_ascii=False),encoding='utf-8')


def generate(source,work_dir,max_edge=768,through=4):
    global OUT,QA
    work_dir=Path(work_dir);OUT=work_dir/'output';QA=work_dir/'qa'
    OUT.mkdir(parents=True,exist_ok=True);QA.mkdir(parents=True,exist_ok=True)
    painter=SharedCanvasPainter(source,max_edge=max_edge)
    (QA/'automatic-guides.json').write_text(json.dumps(dict(gestures=[(p.tolist(),r.tolist()) for p,r in painter.guides],metadata=painter.guide_metadata),ensure_ascii=False,indent=2),encoding='utf-8')
    for layer in range(through):
        started=time.time();complete=painter.paint_phase(layer)
        print(f'Automatic pass {layer+1} rendered in {time.time()-started:.1f}s',flush=True)
        if not complete:break
    painter.export()
    return painter




PLAYER_TEMPLATE_V7 = 'H4sIAAAAAAACCrV9a5fc1JXod/8Kuc1YEq1SV7XbbVtqVV9je4hnwLDcJmvNePoaVelUlWKVpCup+kF1rWVguNjXBDPBBELIBcIMkMnwSOYBMXa81r3/ZMZVbX/iL9y9z0M6UlV3m5XcOHaVzmOfvffZ73NUrBz2ona2HROll/WD5qEV/FACN+w6cy/1amcuzGEbcT346JPMVdo9N0lJ5swNsk7t5JxoDt0+ceY2fLIZR0k2p7SjMCMhDNv0vazneGTDb5MafTD80M98N6ilbTcgTqMCI3b9MPPDbm2DJKkfhRKsE+YiDs78LCDNR9fe2v2X28oGNK4ssKZDK2m2jZ9WEkXZsAPzah237wfb1nkAkRhza6QbEeWF83PG3LN+O4nSqJMpf+P+iPhzRuqGaS0lid+x21EQJdaRxRPHlhaJ3XLbV7tJNAg960jnWKdBWjYFnW6HWY+kfmqFUUjsWq2bEBJaR44dX1463oDn/iAjMOdE+2TjxCl4DvyQWEe8Dvw5Pnpy2Iq2aqn/EtBqtaLEI0kNWkaXe77nkXB96PlpHLjbFPhhv498dcNs1Iq87WHfTbp+aNVHrUGWRSGwNB5kRkoC0mZ0W37YA1IyMYB1GemgD1O3h+1BkgKFceQjX/igISO7PNPqRO1BWtvwU78VELZQpY3Brjaylcqtw2iQUSYsxltKGgW+pxxpeSfbx5dt3lOLOh0QL2sp3hqZbhwPqchYfT/UGosn6/GW0ajX/0K3OQPcQRbZset5yMRFhHoMxiiNkzg9i+Ka285AhtKcmZ2AbNlu4HfDmp+Rfmq1CXLA7rqxdaoySeH87LtbTHKtBmJAxxwI8CeDNPM72zUuvFYau6AALZJtgozQ5RrL8RanAzYeeN2nTaNeg0kuiAYwChZk0rZJ/G4vs5brdTsgGSxRQ5BIt1lfJn07F4leQ0n7bhBIUBqNCpSl4zOgLAIUJgIbbqJx8RWsrgWkk1kNSv//GPgkGzKZtRr5VrJZuIu6rDNZAooVuwlwweZynrieP0itU6dOCbwYmrCB+W6ewH1cype77Ca+W4sTkqbEc+ayZEDm1oeyapLjpEWOiSW4Cp9qua1T7RJZVEv1kSmM1bDHeIIydmJxo2ecPA5UAt1ANO86hi32D91y3lzB8YTn2VOsO+K1wCgcq/DnOCwagRnsBNGmxcxCzh4m4rEbk2QYR6mPEmslJHAzf6Nisjodm5qanusBnLoCTFWorhxZXAIDt9xYtDmdqFu2JO746KYxKAGgBCtwDtLvxrGFJd2mOstn1zk+StsNN9zU4E/pRld89fvdAlm3BbSDiNl+iBpfz/nbCqL2VVtCQcYuav0E0en4wF/gMziL2aviUhIXNnuwVaMCo+EeAsotYo1swBMz7GLWQYbZTDM3G1RMzWOYAdxlWdbqkhI0qDWDv3W7os3Tigp2iRKCIs11FgyV1TgGo7lc0eeZ+soXZCOo1mV+n9DdDdwWCX4IVTNU40Dk2YgNVHL4DAd9cEFtK3Nbg8BN8DmtYqSkWRKF3aFs1o6DceSKv9Q6fmqpA5tCyNWhJEvcTFLG1hXKfLeNWNambYQQPBxU8Zgmkp5EQfonMoZKAFNlAIJCWQaI/SfjWeZmZHKvPcOYHAOf2i4bAbfT6pyYYV9kyVueYX4r5lmsasaJTyMJaZES60pmuNTDmqhC0tXZ5jDPymMOYIEL4YI3jNA5ZduWuXRc7IBHOu4gQHWLCYyY4tapmdx6HPWhAIXT39eBWYWYLR9fWjqZc20ZTSsSAhYNg9i0pIkny+zcEw8+VxHRWuCnMAdDWxZpZmQrq1EarQR3jttKNNxc8EpOuxQkofGvT69hWaBDrat+VvMgFPeDtAatV8G3yMZu1jS3A9wdCnmfU76/e3OuGHc5isFi7j36P6//TBpdi90QTI3MsvoPMF7UlIJS18ueGv+pbSYgGvjPnkq4zL1iFR1lhv3bL4CszOaBd7WZxtEHhFAlXUVVLCl0C/6c3FsMK4I2mo0AE5zlkzMG8CivIq+yoLNgsAcGcUh53HIxF5KtbMlr4VbK4ULDPDEyg8hFeEVU0PG3iJeHBNOpV+f4jN31/ITQmB1igmDQD/cKxfbae0TtpZofemQLHmSkl3IdPbLkHvfQo3CUZwfZs/SZT5gZP4xMkiRRwlOvI259qXXMlUKwk8DMMtNOyurPXcF/6xPPd7Vi2jINYYc0g8q1YzmPqKuh7/LxjV45BqkGISzpqWQri9VshXkyHgeVt35KyynjjxVGf1jyPFRkcx8rNkkYfXxGQkaHVhZ4yr+ywKsUmB/Dh+dvKD4kCpz5c0o7cNNUegbAxJljuM41V8DAh/IEFmTMNSdffDL+4PPx794Z3722e/u7h1//DpaEsTAD97/56NOfT/7l48mNt6F/fOurh6/ee/TBtYefvjx+/aPdz34GY+molQXAB+scEK8KTGBv5pqHFIWWVzB+Zc3AZ0Cn1+AFDr4MK3MIYNBLCSymiJwVKaEWh9KSuv04IDXWkrOAKvacQhMqSqUz9+jajcnN3zy4c2f3xm92//HOgz/enFOYuMJqbHpzhe0TBZyQDgF/CLFNFnW7AanCxoqSM8cm8JXy1K3jBikBxn74T7sf3By/+eH4l39cWWBDOZ/YXpKEciemC7YjpARJrIVRVqyH1qeylwLx3d+/O/7dK+Ov35988M/j7+7s/vbm93ff2L394eT6W+Nvfj9++YPJF7/+r2uvjO+9Pb7x08l7Xz24/6vdd36x+/7fP3r18/H1//nw/uu7n9+EASsLMUUkZSZGrFzUuhC/4klm6+5374HMwP/H3746V9oymlKwqexrc4XlL7zJx4DUbfcIB8ho4nkvMIgNhs3e6BYzqFxv9YMQGZNlsbWwsLm5aW4eM6Oku7BYr9cXYLxgF2RIZWyZqDOxA8zH1/8DmAHIP/rVr2FJuerG6BJltxWGAsbjVwlK4EIXpWYD/oU1yvICKwaZM8e2fXzrlYfXXpUkjW0+ZzRlusSyaVWNe25KhKLu/uLe7p1vc+UUYzD+rwnJKMsJox3SZYAE3jejjGXTmbpOb3qeYVU497MvJrf/OHnzM+AZ1eky5uXEhVMA/9IEhmIJeXsMyjHXrNeteh2NGnY1lQWloMQb0Lw7hEFLbBBDtUJwP/LyhcZf/WHyztcMO+X/fKOMX7s+ee3X47feHN//bZVUQJnGBDnXch1jD0ylgf4ubCL4CmeuDp/uljO3uASSBQ8bbjAgtDnNSOzMNWYpw8P7vxzf+XQGk4Sxr+gJz4rmSuYHW3P0eDtPSB7P9lCOFFanZNlAPJKsAr0Ctfno9Z/u3vuyarZYXiq4hp4KtuDaTx9d+7BklGnHDPlhQ4HSKKYyJ/hpHoctN4//33dXFlhPdQQwmsEnXrOx97DFuebi3r1Lc80luTc3+wsUSUknygrK0oVCVpiTRyFnQT+YjBuPPv4DzOLPJZ0uxQRznIV8fyY//8P47i2ZdUIaaijkU4wKoq7ECFn296I5IS5qCRijz24yyzZ59z8evftv+3CB7TEig5U5NPu1jk8C2OnJte8efnYdAbxzX1KlfBhwLQq9VIhSOOi30AVQVVoWunSqnqvPsUKlQMMqAiOt9f3d6xBpfH/3BthAjDg4opJMe9FmiGFNrUtCAkYkSvb1180H3958eO/e+Ms3Ju/824PvPtn96OVC0uOy580tDn0sMZ35U2Du5IMbwNnxnVvgf9HVfvnvYITQ99/79YN7b2PjW29CI2zA5Nu3xv/rI1ACcLu4+2/9w6PbX0JUxfeGRgzcIwtnweUPA0AMrvAMqJ34ccZJwlh5AcTGDxmuOQdqaTRIwB81r1x5+tyFcxdPX3ru4pW15164eObclSuw7RTIQdDysyrPzVwE9fzp8xcunb/w9JWzpy+dngGneUgdpARLV347U+1DCwvKpR48u32ixIOEKF0S9UmWbCt+qhAQEHCMHuRqSgajok4HvYjyo0vPPqO4oackBLYvgQGtbRyA0DCHgZQb3GmmrP34aRgC3xOSmMqFSOFBFFE6gwwXS3sQeuBKgJOndKIEhm/QEnIUmoe0ziCkeq7haZrRgQgzSrb1IWg9CHKaKW7sO7xV021o9jsa8inqKCASA3C1jqOyeq169ChrMskWus9ULz86AAshEDDPCi5nXvRbrSh8HgIHf4v1jnQBvRtELTe41PPTw7ACJIcwKCSeulp0WBn8Y+QUUKzFU85kjYUstFMQRQt8qcN6TPZkYBlFNOF3g5ZdRAurwVAYwIHDp5PE3Tb9lH5qDIK+s8O+wPSwm/VWFnd2KgMRrj7VSmFDM/byuUBzCdbODh20R6+e9ZJoUwnJpnIOM01NBU16+Nmnu3fvjL/+B9DX8Z3bEOY9+PaL8f1Xd+/cf/Dtm+NvPh3f+lcM8+6+9+j11ycffaPqjDwQHoWBTXN6y/jmTKKD9KNHyw3806kgOTUMxBC2R9swfMPVneYFaithkb/Es2OibQBgzQco9Z2djabjXvZrjXV9arXLMxeHoc3KuPq6zr86lSl9N9Y2nOZGbXoG4wBKLJMfRbDGgV6bN4FSacg132nY/kqJaNufnxfLmvEg7WkCOFIz/6yb9czedhxlXIYu++sAuCYeYAw8GkVfo9yHDGFYjOi/YBxOKxj6ggaAG1Y8twWPfhAorrfhQmgOqUeWKi0stmA/yx1Tbnz8RKHlKFNsu8B1ire4Kzk3OcHIRe2K4cNW+hyphIAJgqS/UDCmVAafyj+tPdcZIZyRrNYxxG2+GzDLcZaLohEnURfDP/hCsIjrldXdoXwG36vVDfYVj5oNJnGamAwaWBfsBOLjFaCRUaCqRWvTafBWhYuLZ0trdR2Bws5O1QQZng97A7vgxE92hYDkOtceZCA/9HGz5wdEg4aV7pRcHz2at12GEesrAqgOT/PzMi6dhBUMHE2MqZXmoj4taGVwUyN2dhq6DJQejUAq5WbE0VyjBdt92QUhnddaKLn4VX9SrGy4IKLY08CehtSzLsOkprdLra6ZBn6bwD7B6jo3wV1mfUtdgm8wg6qVhJbGIHH8jeIpVxYGbsY82lFMzB+LmUwenlXn6dKAftvNmAE30a8mKdF0neoClXqnuQZhQNhlT8ibedVQ50uNqMTmT+CrpirPqDBA+VtVyD3XICFJRln8R+gw7UPT8Qa41BSiA2oHFMxMMQCA0BnCy6zX99t5tAGY+6EbcFFWRBJrKhdpTAFIIjg32HS3U0CmTSCTTotpON5QMPPC+BfyXASaQsQCi/sFWIH+VLyhiIBDKUUciqNUYg6lHHQoYIAUEXYoR48qlcCj8gzwpmKP53lYdwYPosWAWeGHchjXKgIQZVXutBQahChFFKKUwpA2pB8ZoYtoibt5luf3hiJShmcRO5ZdG2ADkg0gTjl1ioERPIGZ0MrtlQRGL+AU/QVk6HaLdgo8t2+KdrjqcQGwruzs0NVWHKWuK0VccRFrAjy4kBBQ+gNArwWBLa3tbxB1vwUEZnSVHPH9lpK49INWcukSrrKyN2jGawE1xKIj6boyZMZ7SIX6MXBRo3maoQzimCS64jQVyasouVuh3YbgOZ1DccldCzd5QhkBMp0LDY0Y8GaDcvkRBSENEzAYq8I4FYSDWwaFNaOEYp6Lwom7Z+XctXlkkAOE7kuRbB8EXZUFeGzDsEUZpXwQg1FURPiDG1BBQxfopfKglI6o55316U4qgrw7J4GPqjQrTyqayyAC1amywCmXuQljeIcOHznPSzFTEVpITLkUXXQ3H4czWZUzpQ3TH4tJmTwo249JrLNQIz4G6KswCVlR4k8G9Oec40wC69hvaIUkPlkahRxzZ3OKB5M5ySTI3DKbDIUdtDtKo+AYx22az/vKpK7MlzSNaxZdlGsWYD5jBMWAj+CgZGo4NkNFMmcWPsi2uVAkbpwtxS322JjWJmOaPEPwSxmV3TqsLbkHRXhzzU23w7aiURuDvCu7dyF5Tzi+5zS9qD3ow3Jml2TnAoJfn9o+72m+pxsX1hx17yMCCootVVgb0gY2ce5jIcShxVQeTWPiS7sgIcMPk4QwHHwoZujdl/wYT4fJ8pIqAmQ6Kg+duWc9S7BEgQE3rAiBEHH7TinDn85mH371zYN793dvfz65/dXkjZfHb364e/tDBVdUHn72yfjNm3iG8ebXD777RDkDcyHcmVz/uXLO61ZMecvHrMhxs6jFaDRjdxuLZrrR2s5I6uCaL0BccJIlumy8SLK5Zc6TvToke6URNNmjgCBVc3gX3qU+A0w9nWl+CRngQAxfCF30In/Q8OEpCC+0yxTQum6mlEWabsZ+TC4BeYNujw6bwUiNboOql8NVBXdyVaxn4pOmW/nzT1IMW4Ro8mpV4CZd8LWMPRg9wtYkGYVkgLOEMC1UyBaB2Bgv8Sh/5W64a6yKhocsiRuYDNZfExLTqDDGC3dbNN9kO0fCDRJEMYHgCetcTPSUKAy2eRTJarwKn2QekoKh5xlezhOaWirPqTql7gy7EWCCyvTzqtXCf79y5fLp2t9eWZ+/cuWJBRiYZloBS+dCvumHXrRpCrCXCCyOuQ4eytm5ttFDMUflNf1ffD6589buRy9PPv948qv7qrzLfdget0ucfCbTeK6qgD5IKB9j0qLrBbwgr9ILAxyQ6JYoc9SH938xee+rmet/f/eNB9/iYef4Fh8A6sEKig/ufLZ74zf/de0V0Ch+nP3N7/HLG69hfYj2jl/7p/GtT76/+0sGjZ90v3Z9/PFvoYsdjwOEEpWQM1zdk0TYFbzecNXsJaTjqJjBYHSfLuB59wK9kGHiGwkqG1UicxpJmRCOA0gBP9CH/YfsO3Db5Ayk0F5CwA0z7hkIW7eZQghZRz2O3fZV4p0F4XH+au25C7DxmMNJcoGD95czR5XMcgsMGYiGu+n6mbCnxRq6IeCkTrmoxublcpfqq9UW6/LQ9yyV341TDXoGYKnygb5qIHYWmzmiObZEXzgIApuTjdfNsEx+hp3IBSTJu3nIR7VujWoh6lnpmgEzqzlmJhjFc267p2l47cagW6o7zSGDxI5Z9hQP1g0Q2ReTHYfwDJmBEl0yz3Elk7JgZ+dFRr3yxJCOn2+MXrRl/PGKDOSzVCY0Bku3R5SG0jB+AF/QJQq5M1wlf8HFf4mITJIH+2hGKkbk9PPnV028ERRhecCe7mW8n96TVdNtQQKr6fas/QIfcBq7izZNSKu4qgCCmpLsdAbcbA0gL1LpAVNrkG6rhoomDfiOm1scoFdFe/puzH9e+1SSdywvhSDkBr1NbbTdIMDTO9h+bDVdzzuHHc9w/LXyMGOY+t3QDaxp+kzWw7aJrYXCXdYsxnJKAruZMMMC0G7BbNrfh6BO4gnbdrUYx25lwFAuEDQIwt78ikPRR/2C3MVvy0zxUboKo+4xYcZW8VNt2C2KBN8ujGxhPFMVtUHhlc5Ni06MxrG7ekRZjFhcqpdH0LPOKvWHigKgOGJynoqigLihhvti0t5kQLXjKQxo8cY3gK3c6ingHi4gSWaHbaNDQfIHI4syN3BE4I89tKWogkA465Q22cALhbEjy4XBrtM41U3m4cHhWWccWBM+zL/mJzGHNbp6EzL66XMXqiEPvv1i8vuPJx/ckD0wO5Jh6wG+lc1Gxj8VbanGi3XI154YUirpPb+ReGL39kYvVo7hnofMZ/HsQSH05It/nPz7rYefXYdgAaMDGkjzuQq/wnT37fEX7zEEGa9M/mJfjovN2xkqjoRWsYP0OiZkDnwo5CVnWIumLoIcD90g7rkWFapRznw+aQbe7340+dd32NUu+aaVKswCTjM7fhCs4R1BR8VXYeB/qi33XQTrDplh3ShIMSTkJROD1ekNgnzZw2FdWNMurBkgQlkPcCiGV/aTCQ2oLV4A3W8gfWvOh6AZLXJuiaj4ltxWAaCISCCmRquBhCPU5xMIp5NsW1P56zsgTSVJWpglSRWzliZtrnz07BwDhxcuPrOzw2IcDB3QvjC7YgiTscZsigOmxKDGyWkYbbQBTqnMasrVUKpEVQhPNrAOeuqULhajSuqdiQZgQ+sG1pvhQ5gND78PEry0f5qyx6k1xEQ0h7Aus14GnqJDvA/jIcbO/jJxKRxhMn/M3kKFFnaUXjwj/zELwHXRR4sGYHXfh9yNf4JPSaNgA5y7wd28VzWba39z4cyVZ84/e/6Sc9J46oXzz5y98tQLZ58+d8k5YYj6+Bkklvr1Z91Yw1gx61XaCoAQc/XdjGLWT/NgK2RnXZ0gAu2RiiL9VF9A3upGD/Y1lUeFC8eWoYPHxhrtX+XxF33Q51UL/qi6OLcoTV6u638BfyGc8dbwVpW2aKh1lc4R48NZA2xaDcnjKVo3fQoPJs+FnpbpQxqlRrAHPd8pm2CbnY8F0UrP1zndfQee5+G52Ww2DHHEm17ur9tgX1KTXviaT01RullxMh2g9+cbNj0TgEX69ojny0Fklw4dM0yGmdRIQV5eApx5vMjEu1QGpueLILwoy1Vyi3NAV0hyfqrp1PMaCp28UmaHYEFBNB1FCc+aDqf96FGYN8UGfciXo1PsfEUtq/HB+kIx2h7JpbNhxmgxGAjpEBavbFoZHhKvqj5kIqoFeFCGrKoe2kOLTWniAA9yLfTZFgW2qgZ+JwPZofOMEGwJ8VjXvJbPOnpULNasrzasuj59UJwfvrIUYgjMKKmZCUjyPlGuKvfDjov0QxztyvdVzMrpbnqZDl4H210CkwowRle3p5DAq/PNJb3c6BE0bpWRV8l2qulmSIs3Jo97BeL2fmfkbPVYH/LRJSpmnqcLWozYqLBRL6+UgDElCTolwWaWUoP3zG2XzEg8QEcPJirB8N2mo9G+sWCkgoLp6XYBqmAmBSPgSbxcXtKLFs7IomE/JlJkStShZK5RbDRmAXhmO6VvDFWbDTLZ6eBpDHNA+fjbbaAMeXgGEpu3i0lFBJOa9D0RuUOb4nNlH2AgmFYgVWzykP+wgqWeMBdV6jeNUsxsMftUKlbDIIt6bXO6IE8h0Bp6aU4Ojs0rH37k/vVZeLKwqeruDVZTP3WKRQ0Gd9q5Ey08PTcy5+nrOyWfz3toiFDuoYYCEW/mhlHuXmcGDu2HwQYwGGXrarAIhMlBaknxiCHu3Vkqi3UXvVqOL1bYawwzFfgGw4mH+5dagrbVutWQ4wsODt+OkVoPOyzuyEO0H7NfWbAOz0xHR2W5GMQQypEXzmsdGvHIfgz5opf8WNqLNkNnLwGgEMyMyYCoGah41WHLmbX50hCWZ1LwecGOd83IeOlojNxp9FpEORoFoI/wLumXb0yuvwWdFCfqHEaQXr2o5+D5XftKEj4FDJEUaO89dhZ5pVJ+YQkYRoV3k58tKUyQMK819HWISrdJwuJu+jVdNS/DX/p9PadKeheiii2FR/sxE6TOc1Vlr0uoVqWXuuBVrUi/V1X5dZjd796e/OpDfJWAvV2Dr9ZQhoNXZq+M8EfdovitmvijLjs7gC9dAnIF+f2SokhbvLVQwZ5mFA7LKVbV/V5oABSmb3KrU84fkyGmQxhJykF8tn+5C4MW1LdVFVbipa8v339w76e06PWYhTUe9WZcd6vGGrje97kW0p0B64MVam6yi8M23gBgSmkJ955D0zQLu4/VjTYJAoKvMg/IyBb3Ac+wN47wiIUeqwBmeAIDaTbe18Hrw/gSsOImhCOWFZeR6ZXlzE2vmgIavchME0Ml7kUZxGBu3MPjoRAvP7E7xlmkxFE8wFMTejmG5XD5pUJKrD4U6bnsLRt2ufUMyCfe9iDPxYQpn6O2o3i7SO7RRZ/vA0AG1uS/DwGpvv4YsBglNXRKqs1CWznflJSUsVNK4qeKiKi7wuD/4HR/z+FY+CsuumgV83L0KNfsPBiejk3kKev7LlQJBeWJRnkdfR+MMV5RDR7E7DOOxz849IAQaT/2INNpRKQaMr6PuwH8J4vUg5YQjlyUzJms0GoE94t2UZOQxaZcnZBRtCUbRa2EXXbWRXCf6/iUmYOoeQ3FXgNntekmntj99p6HLUw/gIL2jNrerLIeT3Fp4OC0D6rmoYgKVHj8WmiorJsjeqV6KvYtqndS14HFO562D9kCVtvgmm/xqJ2GeRZHbFXScKvO4qXK0U5r4AeebJ9zyyxq1HiiWzC/2O+mI0HX8deXFI+4Hl6pdMDs0JgCzLQZRpuaPi9XgeziXgGzZBRp21+RpQnvFwz/VMcgZTXcZjJuGT7Lp6poNh1Bgj5kZy80WWOFL40XvpwmiDM62GiQiTYDr7w9LvkjUXs5yDtWElBK/+lMlGWAABFfiySzWqLbnz0i2Z8OmNkKAg9nfr7EewPWSGm9UYrsJGFA1vIhK/WdHf61WVQF9aFkELhRgdS3XG7cUzLzJLY03h4VUlXCZUqqJKGQxCG/qDIIQPmnNoYmJjkGB1RGGZQ9ES0FSHRLBC/opk5nRJjpSvyfn582qAdgVAiBzgpblbTpeYhuYXV+tFYJFHmmuqpO3n9l/PIHGC3SgDU/ijvgOE/cAGdgeIhYsUOZ376qga4U9gePSviUnZ3CClTq2Fzy+fbRi3JyiRIg1vIqOBipvCAOHTbT8FytWOoj7vvRIgC77UezeXbDjpqNH4AWliUxKWcVQQjP3QE9FufdI1Gr55+nQ79P4zUmeli7cZqMNSimgjcVwxCzzUPREYhVDINdEbMqXjkPwF2JwwR62MvYWtiBCpkSQ6dsni1Lln0AodGmoFMSgSqZjHfD0mmHXcEIdIPRWlmBr1sgUp/iSQnfcnFMXGeYYXNtsaX5YQhlXFVh2SHX9HF9ufDZDoiLFxuKKp5oKZ0N2VMHQaUzTPnB/rMdGx50GmRXwjUsO+byzo/Tq0cBvhT7+ZVS/2oulHnpcV3U9IuGvLhv7WvyDpXvPm88Jmqw3VW0KlU2gZPwwHsindOZj/BX8zG1Bh9l1SvIoqGXKouS76ffDvNKwtGj+SO7bz37PYAXwqugYMxiIEiF3Z+waVGC3WDd83YFPux3dUIUNuj6tiiB4GvUj10B+f/3hjX6rDduTL66hTcTvvx6fO+d3ff/nlVX2EvnDIEDgDyGuYOUZlY2U93T5zgTRU1Z7CsPuvkRc+7IlqXDtlP1evWobXEJw8/qATWHYj/e4XRaPZTe7x6NAP3n4Qe7E3RRFHi1nA09WrhxZlZ/97iidJhPym9vsGbRijUZ9lWfvpfCSxS0CkEPSnHIvjeoDrgIxZdaVR/evz3+5f9mdzpQFP/E+1E8oBKU5AwWVM6Ir/LfCVijdaCcxxALI3+rPyNQJoQmd8w8gKsaMhko3yCFLW27WbsnzmQYGAtfMQDvQrBqaqk0pL8CopJG4RVxgenKxgkz3lZHeWrLp07ffTPQs+oFPHatXTzu7BwEH7gCmoZl8Knfj1B1Q20HEICoBmWcVlzpZD8U4ewxzeY/Hyl+4ZF5f+RSKaFgxExtgjFIAueFi89wfXyOvuQHz9LVeAaA31BZN4Z4E8pS6Q83bNXi7awHUZj4DXP6E+bqSNcNd98byi67ngyLw1dBlcNXEvw00zjwM23h8t/93cL6gm7GEV7JcE3KJvgmJcHILaQCHCv4s4IKWEA36E0MLh0aveutDznTZF2hPSa/wQzJHL5zGWwPq+xlQd+I3aZiu8kykHz/EBmRsXAfb7EIGUwkncB/EqcyR4rNi2B4JOawMxxDpb+DorILoLPmsCRi+rUfOsHklR4mzfxspViC3XQEpHrosotF2C0jbvOnAen7muEcfMWrTy1TjTRmLCRATfuFWdCmfNw+EKcNYL43Fe8gNl7It6FeJdsowwW/wMiXluqj6JFUU+Vflaev/LigG4b4RXn2cz4q+FM22w2yvybb4qmdJYH0iD/wD49SnseH8eBmDX8oV9WHrBVDTvg8y66za3mSVRFQVipUcmBAGcI6DaqxeRGj8L0Bsnh7PwDPkM4+81lQvMf8H0GOss/UWXozEw4E1j8ADEtNJV0vtrwobAuxoxqM2Zkwe8xN6wKqfLUaNt3bdmR0Z15jd+gFQkOMM6QCmSFCGXqKb9BFxEG+QVN1JM+oqJQxQymq4l05mcCFni57DaviRdjlQwsZQL8Zmz0SslfaiUeby5mbQcmnh2aiAALP5ey39JaJfPmbcwlJRaWi192ps2Lf8lvJFKaq52X88hsK1XvyufEofG9pwrRzZZjPeC8hf5/hsngzUgbEjA5kjfh6SsUnVQSAZkwVr7TvceoeDmw2ISU39hjE1AXO+Nq+bkqI8zglwl8AoEkeI8fe62VJaWP9EJiPrxjhSz1/jle4Zr69xW41s5eb2JXx7+++r86X2fUY2MoXhPm0qddLZm0a8lj63aoF/nuqC+y/D/P/AOFca2QwZgAA'

def _envelope_v7(raw, filename=None):
    result=dict(encoding='gzip-base64',payload=base64.b64encode(gzip.compress(raw,compresslevel=6,mtime=0)).decode())
    if filename:result['filename']=filename
    return json.dumps(result,ensure_ascii=False,separators=(',',':'))

def main():
    import tempfile
    parser=argparse.ArgumentParser(description='Automatic portrait painting v7.2 and offline player')
    parser.add_argument('--source',type=Path,required=True,help='Any local RGB/RGBA portrait or figure image')
    parser.add_argument('--output',type=Path,default=Path('portrait-painting-v7.2.html'))
    parser.add_argument('--max-edge',type=int,default=768,help='Analysis/rendering resolution, default 768px longest side')
    args=parser.parse_args()
    if not 128<=args.max_edge<=2048:parser.error('--max-edge must be between 128 and 2048')
    with tempfile.TemporaryDirectory(prefix='portrait-v7-') as temporary:
        painter=generate(args.source,Path(temporary),args.max_edge,4)
        data=json.loads((Path(temporary)/'qa/painting-data.json').read_text(encoding='utf-8'))
    template=gzip.decompress(base64.b64decode(PLAYER_TEMPLATE_V7)).decode()
    full_source=Path(__file__).read_text(encoding='utf-8')
    output=package_player(template,_envelope_v7(json.dumps(data,ensure_ascii=False,separators=(',',':')).encode()),
                          _envelope_v7(full_source.encode(),'portrait-painting-v7.2.py'))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(output,encoding='utf-8')
    print('Saved '+str(args.output.resolve()),flush=True)
    if getattr(painter,'construction_blocked',None):
        print(json.dumps(dict(status='incomplete',blocked=painter.construction_blocked)),flush=True)
        raise SystemExit(1)

if __name__=='__main__':main()
