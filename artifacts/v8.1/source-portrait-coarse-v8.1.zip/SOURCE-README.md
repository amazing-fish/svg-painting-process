# portrait-coarse-v8.1 完整实验源码

此归档保留真实模块目录，不是默认 v7.2 自动生成器的拼接单文件。
固定提交：`e393e3cd7473e607b6a6061d141b027b57d73f3d`。源码可离线查看；执行仍需要 Python 3.12 与 requirements.txt 中的库。

安装依赖后，在解压根目录执行：

```powershell
python -m experiments.portrait_coarse --source inputs/image.png --guides inputs/guides.json --provenance inputs/provenance.json --output output --through 2
```

原图文件、显式 guide、provenance 及其绑定的原始候选文件需自行提供；未包含在归档中。公开 HTML 只包含已授权参考预览。输入校验与 SHA 绑定不放宽，不能从预览推造输入。
详细输入契约见 experiments/portrait_coarse/README.md。未完成走势会保存部分画谱并返回 1；源码完整不等于本次底形已完成，也不代表人物效果或绘画自然度验收通过。
